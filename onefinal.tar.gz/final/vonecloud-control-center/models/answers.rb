# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'fileutils'
require 'yaml'

class Answers < Sequel::Model(:answers)
    PROXY_FILE = '/usr/lib/one/vonecloud-control-center/proxy.yaml'

    attr_accessor :errors

    def before_create
        self.created_at ||= Time.now
        self.version ||= Version.last[:version]
        self.body = self.body.to_json if !self.body.instance_of?(String)
    end

    def valid?
        @errors = []

        ########################################################################
        # validate ldap_servers
        ########################################################################

        body_hash["ldapserver"].each do |id, ldapserver|
            fieldset = "ldapserver-#{id}"

            fields = [
                ["servername", required: true],
                #["user"],
                #["password"],
                ["auth_method", in: %w(simple simple_tls)],
                ["encryption", allow_null: true, in: %w(simple_tls)],
                ["host", required: true],
                ["port", required: true],
                ["base", required: true]
                # ["group"],
                # ["user_field"],
                # ["group_field"],
                # ["user_group_field"],
            ]

            fields.each do |e|
                field, opts = e
                param ldapserver[field], {fieldset: fieldset, field: field}, opts
            end
        end if body_hash["ldapserver"]

        ########################################################################
        # validate ec2 global
        ########################################################################

        # Nothing to see here...

        ########################################################################
        # validate ec2 regions
        ########################################################################

        body_hash["ec2_region"].each do |id, ec2_region|
            fieldset = "ec2_region-#{id}"

            fields = [
                ["region_name", required: true],
                # ["default", required: true],
                ["access_key_id", required: true],
                ["secret_access_key", required: true],
                ["m1_small", required: true],
                ["m1_large", required: true],
                ["m1_xlarge", required: true]
            ]

            fields.each do |e|
                field, opts = e
                param ec2_region[field], {fieldset: fieldset, field: field}, opts
            end
        end if body_hash["ec2_region"]

        ########################################################################
        # validate az global
        ########################################################################

        # Nothing to see here...

        ########################################################################
        # validate az regions
        ########################################################################

        body_hash["az_region"].each do |id, az_region|
            fieldset = "az_region-#{id}"

            fields = [
                ["region_name", in: ["West Europe", "North Europe", "East US", "South Central US", "West US", "East Asia", "Southeast Asia", "Japan West", "Brazil South"]],
                # ["default", required: true],
                ["pem_management_cert", required: true],
                ["subscription_id", required: true],
                # ["management_endpoint", required: true],
                ["small", required: true],
                ["medium", required: true],
                ["large", required: true]
            ]

            fields.each do |e|
                field, opts = e
                param az_region[field], {fieldset: fieldset, field: field}, opts
            end
        end if body_hash["az_region"]

        ########################################################################
        # validate sl regions
        ########################################################################

        body_hash["sl_region"].each do |id, sl_region|
            fieldset = "sl_region-#{id}"

            # TODO
            fields = [
                ["region_name", required: true],
                # ["default", required: true],
                ["username", required: true],
                ["api_key", required: true],
                ["slcci_small", required: true],
                ["slcci_medium", required: true],
                ["slcci_large", required: true]
            ]

            fields.each do |e|
                field, opts = e
                param sl_region[field], {fieldset: fieldset, field: field}, opts
            end
        end if body_hash["sl_region"]


        # Return error status
        @errors.empty?
    end

    def body_hash
        if self.body.instance_of?(String)
            JSON.parse(self.body)
        else
            self.body
        end
    end

    def param(val, error_info, opts)
        if opts[:allow_null]
            return if val.nil? || val.empty?
        end

        if opts[:required]
            if val.nil? || val.empty?
                error error_info, "Cannot be empty"
            end
        end

        if opts[:in]
            if !opts[:in].include?(val)
                error error_info, "Allowed values: #{opts[:in].join(', ')}."
            end
        end
    end

    def error(error_info, msg)
        @errors << error_info.merge(:message => msg)
    end

    def read_proxy_conf
        @proxy_uri = nil
        if File.exist? PROXY_FILE
            proxy = YAML.load_file(PROXY_FILE)
            if proxy && proxy['host']
                auth = ''
                auth = "#{proxy['user']}:#{proxy['password']}@" if proxy['user']
                @proxy_uri = "http://#{auth}#{proxy['host']}:#{proxy['port']}"
            end
        end
    end

    def erb_vars
        @erb_vars ||= {}
    end

    def reconfigure
        read_proxy_conf

        if body_hash["ldapserver"]
            reconfigure_ldapserver
            erb_vars[:ldap_enabled] = true
        end

        reconfigure_ec2_region if body_hash["ec2_region"]
        reconfigure_az_region  if body_hash["az_region"]
        reconfigure_sl_region  if body_hash["sl_region"]
    end

    def reconfigure_ldapserver
        ########################################################################
        # Ldap Auth -- /etc/one/auth/ldap_auth.conf
        ########################################################################

        conf_file = '/etc/one/auth/ldap_auth.conf'

        ldap_auth_conf = {}
        ldap_auth_conf[:order] = []

        body_hash["ldapserver"].each do |_,ldapserver|
            servername = ldapserver.delete("servername")

            server_conf = {}

            ldapserver.each do |k,v|
                next if v.nil? || v.empty?
                server_conf[k.to_sym] = v
            end

            # integers
            [:port].each do |key|
                server_conf[key] = server_conf[key].to_i
            end

            # symbols
            [:auth_method].each do |key|
                server_conf[key] = server_conf[key].to_sym
            end

            ldap_auth_conf_defaults = {
                mapping_generate: true,
                mapping_timeout: 300,
                mapping_filename: "server1.yaml",
                mapping_key: "GROUP_DN",
                mapping_default: 1
            }

            ldap_auth_conf[servername] = ldap_auth_conf_defaults.merge(server_conf)

            ldap_auth_conf[:order] << servername
        end

        File.open(conf_file,'w') do |f|
            f.puts(ldap_auth_conf.to_yaml)
        end
    end

    def reconfigure_ec2_region
        ########################################################################
        # EC2 Region -- /etc/one/ec2_driver.conf
        ########################################################################

        conf_file = '/etc/one/ec2_driver.conf'
        key       = "ec2_region"

        conf = {
            "instance_types" => {
                "m1.small"     =>  {"cpu"=>1,   "memory"=>1.7},
                "m1.medium"    =>  {"cpu"=>1,   "memory"=>3.75},
                "m1.large"     =>  {"cpu"=>2,   "memory"=>7.5},
                "m1.xlarge"    =>  {"cpu"=>4,   "memory"=>15},
                "m3.xlarge"    =>  {"cpu"=>4,   "memory"=>15},
                "m3.2xlarge8"  =>  {"cpu"=>26,  "memory"=>30},
                "c1.medium"    =>  {"cpu"=>2,   "memory"=>1.7},
                "c1.xlarge"    =>  {"cpu"=>8,   "memory"=>7},
                "cc2.8xlarge"  =>  {"cpu"=>32,  "memory"=>60.5},
                "m2.xlarge"    =>  {"cpu"=>2,   "memory"=>17.1},
                "m2.2xlarge4"  =>  {"cpu"=>13,  "memory"=>34.2},
                "m2.4xlarge8"  =>  {"cpu"=>26,  "memory"=>68.4},
                "cr1.8xlarge"  =>  {"cpu"=>32,  "memory"=>244},
                "hi1.4xlarge"  =>  {"cpu"=>16,  "memory"=>60.5},
                "hs1.8xlarge"  =>  {"cpu"=>16,  "memory"=>117},
                "t1.micro"     =>  {"cpu"=>1,   "memory"=>0.615},
                "cg1.4xlarge"  =>  {"cpu"=>16,  "memory"=>22.5}
            },
            "regions" => {}
        }

        default_found = false

        body_hash[key].each do |_,item|
            item_conf = {}

            default = item.delete("default")

            # Capacity
            m1_small  = item.delete("m1_small")  || 0
            m1_large  = item.delete("m1_large")  || 0
            m1_xlarge = item.delete("m1_xlarge") || 0

            item.each do |k,v|
                next if v.nil? || v.empty?
                item_conf[k] = v
            end

            item_conf["capacity"] = {
                "m1.small"  => m1_small.to_i,
                "m1.large"  => m1_large.to_i,
                "m1.xlarge" => m1_xlarge.to_i
            }

            if !default_found && default
                region_name   = 'default'
                default_found = true
            else
                region_name = item_conf["region_name"]
            end

            conf["regions"][region_name] = item_conf
        end

        # Global Options
        global_opts = {
            "proxy_uri" => @proxy_uri
        }

        conf.merge!(global_opts)

        File.open(conf_file,'w') do |f|
            f.puts conf.to_yaml
        end
    end

    def reconfigure_az_region
        ########################################################################
        # AZ Region -- /etc/one/az_driver.conf
        ########################################################################

        conf_file = '/etc/one/az_driver.conf'
        key       = "az_region"

        conf = {
            "instance_types" => {
                "ExtraSmall"  => {"cpu"=>0.1, "memory"=>0.75},
                 "Small"      => {"cpu"=>1,   "memory"=>1.75},
                 "Medium"     => {"cpu"=>2,   "memory"=>3.5},
                 "Large"      => {"cpu"=>4,   "memory"=>7},
                 "ExtraLarge" => {"cpu"=>8,   "memory"=>14},
                 "A5"         => {"cpu"=>2,   "memory"=>14},
                 "A6"         => {"cpu"=>4,   "memory"=>28},
                 "A7"         => {"cpu"=>8,   "memory"=>56},
                 "A8"         => {"cpu"=>8,   "memory"=>56},
                 "A9"         => {"cpu"=>16,  "memory"=>112}
            },
            "regions" => {}
        }

        default_found = false

        body_hash[key].each do |_,item|
            item_conf = {}

            default = item.delete("default")

            # Capacity
            small  = item.delete("small")  || 0
            medium = item.delete("medium")  || 0
            large  = item.delete("large") || 0

            # File Fields

            file_fields = %w(pem_management_cert)

            safe_name = item["region_name"].gsub(/[^0-9A-Za-z_-]/,"")

            file_fields.each do |file_field|
                if item[file_field]
                    file_path = "/etc/one/#{key}_#{safe_name}_#{file_field}.pem"
                    File.open(file_path, 'w') do |f|
                        f.write(item[file_field])
                    end
                    item[file_field] = file_path
                end
            end

            # Regular Fields

            item.each do |k,v|
                next if v.nil? || v.empty?
                item_conf[k] = v
            end

            item_conf["capacity"] = {
                "Small"  => small.to_i,
                "Medium" => medium.to_i,
                "Large"  => large.to_i
            }

            if !default_found && default
                region_name   = 'default'
                default_found = true
            else
                region_name = item_conf["region_name"].downcase.gsub(" ","-")
            end

            conf["regions"][region_name] = item_conf
        end

        # Global Options
        global_opts = {
            "proxy_uri" => @proxy_uri
        }

        conf.merge!(global_opts)

        File.open(conf_file,'w') do |f|
            f.puts conf.to_yaml
        end
    end

    def reconfigure_sl_region
        ########################################################################
        # SL Region -- /etc/one/sl_driver.conf
        ########################################################################

        conf_file = '/etc/one/sl_driver.conf'
        key       = "sl_region"

        conf = {
            "instance_types" => {
                "slcci.small"  => {"cpu" => 1, "memory" => 1},
                "slcci.medium" => {"cpu" => 2, "memory" => 4},
                "slcci.large"  => {"cpu" => 4, "memory" => 8}
            },
            "regions" => {}
        }

        default_found = false

        body_hash[key].each do |_,item|
            item_conf = {}

            default = item.delete("default")

            # Capacity
            slcci_small   = item.delete("slcci_small")   || 0
            slcci_medium  = item.delete("slcci_medium")  || 0
            slcci_large   = item.delete("slcci_large")   || 0

            item.each do |k,v|
                next if v.nil? || v.empty?
                item_conf[k] = v
            end

            item_conf["capacity"] = {
                "slcci.small"  => slcci_small.to_i,
                "slcci.medium" => slcci_medium.to_i,
                "slcci.large"  => slcci_large.to_i
            }

            if !default_found && default
                region_name   = 'default'
                default_found = true
            else
                region_name = item_conf["region_name"]
            end

            conf["regions"][region_name] = item_conf
        end

        File.open(conf_file,'w') do |f|
            f.puts conf.to_yaml
        end
    end
end
