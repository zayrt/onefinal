# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

class JobQueue < Sequel::Model(:job_queues)
    set_dataset dataset.order(:id)

    def before_create
        self.created_at ||= Time.now

        jobs = []
        self[:jobs].each do |j|
            jobs << Job.create(j.merge(:visible => 0))[:id]
        end

        self[:jobs] = jobs.join(",")
    end

    def run
        Thread.new {
            cancel_jobs = false

            jobs.each do |job|
                next if job.state == "finished"

                if job.state == "pending" && !cancel_jobs
                    job.update(:visible => 1)

                    job.run_sync

                    if job.fail?
                        cancel_jobs = true
                    else
                        if job.get_body["stop_queue"]
                            return
                        end
                    end
                else
                    job.update(:cancelled => true)
                end
            end

            self.update(:finished => 1)
        }
    end

    def jobs
        jobs = []

        self[:jobs].split(",").each do |job_id|
            jobs << Job.find(:id => job_id)
        end

        jobs
    end
end
