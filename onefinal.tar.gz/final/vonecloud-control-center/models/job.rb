# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'open3'
require 'json'

class Job < Sequel::Model
    CALLBACKS = {
        :reconfigure => Proc.new {|obj|
            answers = Answers.last
            if answers
                answers.errors = []
                answers.update(:applied => true)
            end
        },
        :bootstrap => Proc.new {|obj|
            Version.dataset.update(:bootstrap => true)
        },
        :add_file => Proc.new {|obj, *filename|
            obj.update(:file => filename.join)
        }
    }
    set_dataset dataset.order(:id)

    def before_create
        self.created_at ||= Time.now
        self.body = self.body.to_json if !self.body.instance_of?(String)
    end

    def run_sync
        begin
            cmdline = get_cmd
            self.update(:start_time => Time.now, :cmdline => cmdline.join(" "))

            stdin, stdout, stderr, wait_thr = Open3.popen3(*cmdline)
            pid = wait_thr[:pid]

            self.update(:pid => pid)

            # Wait for it to finish
            exit_status = wait_thr.value

            self.update(:stdout      => stdout.read,
                        :stderr      => stderr.read,
                        :end_time    => Time.now,
                        :exit_status => exit_status)

            # Close descriptors
            [stdin, stdout, stderr].each{|io| io.close}

            if exit_status == 0
                success_cb_args = parse_args(get_body["success_cb_args"])
                CALLBACKS[self.success_cb.to_sym].call(self,*success_cb_args) rescue nil
            end
        rescue Exception => e
            stderr = "#{e.message}\n#{e.backtrace}\n"

            stderr << self[:stderr] if self[:stderr] && self[:stderr].empty?

            self.update(:stderr      => stderr,
                        :end_time    => Time.now,
                        :exit_status => 1)
        end
    end

    def run
        Thread.new {
            run_sync
        }
    end

    def get_body
        JSON.parse(self[:body])
    end

    def get_cmd
        body = get_body

        cmd    = body["cmd"]
        args   = parse_args(body["args"])
        setsid = body["setsid"]

        cmd = File.join(SCRIPTS_DIR, cmd) if !cmd.start_with? "/"

        the_cmd = [cmd].flatten
        the_cmd = (the_cmd << args).flatten if args

        the_cmd.unshift "sudo" if body["sudo"]
        the_cmd.unshift "setsid" if setsid

        the_cmd
    end

    def parse_args(the_args)
        return nil if the_args.nil?

        args = []
        the_args.each do |arg|
            arg = arg.gsub("${ID}",self[:id].to_s)
            args << arg.to_s
        end

        args
    end

    def state
        if self[:cancelled]
            "cancelled"
        else
            if !self[:start_time]
                "pending"
            elsif self[:start_time] && !self[:end_time]
                "running"
            else
                "finished"
            end
        end
    end

    def finished?
        state == "finished"
    end

    def success?
        self[:exit_status] == 0 if self[:exit_status]
    end

    def fail?
        self[:exit_status] != 0 if self[:exit_status]
    end

    def to_hash
        h = super

        h.merge({
            :state    => state,
            :finished => finished?,
            :success  => success?,
            :fail     => fail?
        })
    end
end
