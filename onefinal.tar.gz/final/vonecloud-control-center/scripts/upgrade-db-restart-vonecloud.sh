#!/bin/bash

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

################################################################################
# This script stops the vOneCloud Control Center server and performs the database
# migration.
#
# It in turn calls a second script `start-vonecloud.rb` that will belong to the
# updated package, which collects the output of this job, updates the
# _potentially_ modified database with the stdout, stderr and exit_status of
# this script.
################################################################################

SHARE_LOCATION=/usr/share/one/vonecloud-control-center
LIB_LOCATION=/usr/lib/one/vonecloud-control-center

SCRIPTS_DIR=$LIB_LOCATION/scripts
POST_INSTALL_DIR=$SHARE_LOCATION/post-install

JOB_ID=$1

STDOUT=`mktemp`
STDERR=`mktemp`

(
    set -e

    cd ${LIB_LOCATION}

    rake db:migrate:up

    # run local post install script
    VERSION=$(sqlite3 -noheader -list /var/lib/one/vonecloud.db 'select version from versions order by id desc limit 1;'|xargs)

    POST_INSTALL_SCRIPT="${POST_INSTALL_DIR}/post-install-${VERSION}.sh"

    if [ -f "$POST_INSTALL_SCRIPT" ]; then
        bash "${POST_INSTALL_SCRIPT}"
    fi


) >$STDOUT 2>$STDERR

EXIT_STATUS=$?

# Call script that starts the service and writes the output to the DB
setsid ruby -wd $SCRIPTS_DIR/vonecloud_start_after_migrate.rb $JOB_ID $STDOUT $STDERR $EXIT_STATUS &
