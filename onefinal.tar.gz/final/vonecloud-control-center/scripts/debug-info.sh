#!/bin/bash

FILE_NAME="$1"

mkdir -p $(dirname $FILE_NAME)

TEMP_DIR=$(mktemp -d)

(
    cd $TEMP_DIR

    COMMANDS="vdc acl cluster datastore group host image template user vm vnet"

    for name in $COMMANDS; do
        cmd=one${name}
        ${cmd} list > ${cmd}.list 2>&1
        ${cmd} list -x > ${cmd}.list.xml 2>&1

        ids=$(${cmd} list | grep -v ID | awk '{print $1}')
        for i in $ids; do
            ${cmd} show $i > ${cmd}.show.${i} 2>&1
            ${cmd} show -x $i > ${cmd}.show.${i}.xml 2>&1
        done
    done
)

tar cvzf $FILE_NAME \
    /var/log/one/oned.log \
    /var/lib/one/config \
    $TEMP_DIR

