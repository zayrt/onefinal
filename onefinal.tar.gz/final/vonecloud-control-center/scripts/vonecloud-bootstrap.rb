#!/usr/bin/env ruby

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

# This script generates required resources to bootstrap vOneCloud. It must be
# idempotent.
# The list of resources generated can be found at the end of the file in yaml
# format.

ONE_LOCATION = nil
RUBY_LIB_LOCATION="/usr/lib/one/ruby"
BOOTSTRAP_DIR="/usr/share/one/vonecloud-control-center/bootstrap"

$: << RUBY_LIB_LOCATION
$: << RUBY_LIB_LOCATION+"/cli"

require 'yaml'
require 'pp'

require 'opennebula'
require 'one_helper'

include OpenNebula
include OpenNebulaHelper

def wait_connection
    client = OpenNebulaHelper::OneHelper.get_client
    user = User.new(User.build_xml(User::SELF),client)

    rc = nil

    20.times do
        rc = user.info

        if OpenNebula.is_error?(rc)
            sleep 0.5
        else
            break
        end
    end

    if OpenNebula.is_error?(rc)
        STDERR.puts rc.message
        exit 1
    end
end

def check_rc(rc)
    if OpenNebula.is_error?(rc)
        STDERR.puts rc.message
        exit -1
    end
end

def log(msg,opts={})
    if opts[:no_newline]
        print msg
    else
        puts msg
    end
end

class OpenNebulaResource
    attr_accessor :type

    RESOURCE_CLASS = {
        :user  => OpenNebula::User,
        :group => OpenNebula::Group
    }

    def initialize(item)
        @client = OpenNebulaHelper::OneHelper.get_client

        @type   = item.delete(:type)
        @update = item.delete(:update)
        @group  = item.delete(:group)

        @class = RESOURCE_CLASS[@type]

        @item = item
        @id   = get_id
    end

    def exists?
        !!@id
    end

    def get_id(name=nil, type=nil)
        name ||= @item[:name]
        type ||= @type.to_s.upcase

        status, id = OpenNebulaHelper.rname_to_id(name, type)
        status == 0 ? id : nil
    end

    def create
        if !exists?
            send("create_#{@type}")
            chgrp
            update_resource
        end
    end

    def create_user
        allocate_resource(@item[:name], @item[:password])
    end

    def chgrp
        if @group !~ /^[0-9]+$/
            group_id = get_id(@group, "GROUP")
        else
            group_id = @group.to_i
        end

        res = @class.new_with_id(@id, @client)
        check_rc res.chgrp(group_id)
    end

    def update_resource
        append = @update.delete(:append) || false

        template = ""
        @update.each do |k,v|
            key = k.to_s.upcase
            v.gsub!(/"/,'\"')

            template << %Q{#{key}="#{v}"}
        end

        res = @class.new_with_id(@id, @client)
        check_rc res.update(template, append)
    end

    def allocate_resource(*args)
        res = @class.new(@class.build_xml, @client)
        check_rc res.allocate(*args)
        @id = res.id.to_i if res.id
    end
end

def get_bootstrap_version(f)
    f.scan(/\d[\d.]*\d/).first rescue ""
end

wait_connection

from_version    = ARGV[0]
is_upgrade      = ARGV[1] == "1"

# Compatibility with vOneCloud 1.2
if from_version =~ /\.yaml$/
    # This is vOneCloud 1.2
    from_version = "1.2"
    is_upgrade   = true
end

yaml_files = Dir[File.join(BOOTSTRAP_DIR, '*')].sort do |a,b|
    get_bootstrap_version(a) <=> get_bootstrap_version(b)
end rescue []

yaml_files.each do |bootstrap_yaml|
    if is_upgrade
        next if get_bootstrap_version(bootstrap_yaml) <= from_version
    else
        next if get_bootstrap_version(bootstrap_yaml) < from_version
    end

    log "* Migrator #{get_bootstrap_version(bootstrap_yaml)} *"

    resources = YAML.load_file(bootstrap_yaml) rescue []

    resources.each do |r|
        log "=> Processing resource:"
        log PP.pp(r,'')

        resource = OpenNebulaResource.new(r)

        if resource.exists?
            log "Skipping: it already exists."
        else
            log "Creating... ", { :no_newline => true }
            resource.create
            log "OK"
        end
    end if resources
end
