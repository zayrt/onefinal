#!/bin/bash -e

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

STATE="${1-status}"

wait_for_one() {
    RUNNING=false
    for i in $(seq 0 20); do
        oneuser show > /dev/null && RUNNING=true && break
        sleep 1
    done

    if [ "$RUNNING" = "false" ]; then
        echo "Unable to connect to OpenNebula" >&2
        exit 1
    fi
}

start() {
    sudo service opennebula start

    wait_for_one

    sudo service opennebula-flow start
    sudo service opennebula-novnc start
}

stop() {
    sudo service opennebula-flow stop
    sudo service opennebula-novnc stop
    sudo service opennebula stop
}

case "$STATE" in
start)
    start
    ;;
restart)
    stop
    sleep 1
    start
    ;;
stop)
    stop
    ;;
status)
    sudo service opennebula status
    ;;
esac
