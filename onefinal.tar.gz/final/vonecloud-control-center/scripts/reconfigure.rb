#!/usr/bin/env ruby
# -*- coding: utf-8 -*-

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

ROOT_DIR = File.join File.dirname(__FILE__), '..'

$: << ROOT_DIR

require 'yaml'
require 'json'
require 'sequel'
require 'fileutils'
require 'erb'

################################################################################
# Configuration
################################################################################

ETC_LOCATION = "/etc/one/"

CONFIG_FILE = File.join ROOT_DIR, "config.yaml"

begin
    CONFIG = YAML.load_file CONFIG_FILE
    DATABASE_URL = "sqlite://" + CONFIG[:db_path]
rescue
    raise "No config file #{CONFIG_FILE} readable/found/valid yaml syntax."
end

DB = Sequel.connect(DATABASE_URL)

# Load models
models_path = File.join ROOT_DIR, "models", "*.rb"
Dir[models_path].each{|m| require m}

# Reconfigure User Conf
answers = Answers.last
answers.reconfigure if answers

# Get the vars for ERB reconfigurations
erb_vars = answers.erb_vars

# Static Conf
files_path = CONFIG[:files_path]

Dir.chdir files_path

files = YAML.load_file('files.yaml')

error = false

files.each do |file|
    source = file[:source]
    destination = file[:destination]
    action = file[:action] || :cp

    next unless File.exists? source

    case action
    when :cp
        begin
            FileUtils.mkdir_p File.dirname(destination)

            puts "cp #{source} #{destination}"
            FileUtils.cp source, destination
        rescue => e
            STDERR.puts "Error copying '#{source}' '#{destination}': #{e.message} "
            error = true
        end
    when :erb
        begin
            FileUtils.mkdir_p File.dirname(destination)

            source_template = ERB.new(File.read(source))

            puts "erb #{source} #{destination}"
            File.open(destination, 'w'){|f| f.write(source_template.result(binding))}
        rescue => e
            STDERR.puts "Error generating erb template '#{source}' '#{destination}': #{e.message} "
            error = true
        end
    when :ln_s
        begin
            FileUtils.mkdir_p File.dirname(destination)

            puts "ln_s #{source} #{destination}"
            FileUtils.ln_sf source, destination
        rescue => e
            STDERR.puts "Error making symlink '#{source}' '#{destination}': #{e.message} "
            error = true
        end
    when :rm
        puts "rm #{source}"
        FileUtils.rm source
    end
end

exit(-1) if error

exit 0
