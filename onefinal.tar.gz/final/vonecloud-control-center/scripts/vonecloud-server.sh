#!/bin/bash

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

STATE="${1-status}"

case "$STATE" in
start)
    sudo systemctl start vonecloud-control-center
    ;;
stop)
    sudo systemctl stop vonecloud-control-center
    ;;
restart)
    sudo systemctl restart vonecloud-control-center
    ;;
status)
    sudo systemctl status vonecloud-control-center
    ;;
esac
