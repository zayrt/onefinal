#!/usr/bin/env ruby

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

################################################################################
# Connect to database
################################################################################

require 'yaml'
require 'sequel'

$: << '.'

SCRIPTS_DIR = File.dirname(__FILE__)
ROOT_DIR    = File.join(SCRIPTS_DIR,'..')

CONFIG_FILE = "#{ROOT_DIR}/config.yaml"
CONFIG      = YAML.load_file(CONFIG_FILE)

DATABASE_URL = "sqlite://" + CONFIG[:db_path]
DB           = Sequel.connect(DATABASE_URL)

SCRIPTS_DIR = File.join(ROOT_DIR, CONFIG[:scripts_dir])

# Load models
Dir[File.join(ROOT_DIR, 'models/*.rb')].each{|m| require m}

################################################################################
# Run
################################################################################

job_id, stdout_f, stderr_f, exit_status = ARGV

if job_id
    job = Job.find(:id => job_id)

    job.update(:stdout      => File.read(stdout_f),
               :stderr      => File.read(stderr_f),
               :end_time    => Time.now,
               :exit_status => exit_status)
end

File.unlink(stdout_f)
File.unlink(stderr_f)

system("#{SCRIPTS_DIR}/vonecloud-server.sh restart")
