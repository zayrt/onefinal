#!/usr/bin/env ruby
# -*- coding: utf-8 -*-

# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'sinatra'

require 'yaml'
require 'json'
require 'sequel'
require 'net/http'
require 'uri'
require 'pp'

################################################################################
# Configuration
################################################################################
ROOT_DIR = File.dirname(__FILE__)

LOG_LOCATION   = "/var/log/one"
FILE_LOCATION = "/var/lib/one/job-files"

CONFIG_FILE = "#{ROOT_DIR}/config.yaml"
PROXY_FILE  = "#{ROOT_DIR}/proxy.yaml"

begin
    CONFIG = YAML.load_file(CONFIG_FILE)
    PROXY = YAML.load_file(PROXY_FILE)
    DATABASE_URL = "sqlite://" + CONFIG[:db_path]
rescue
    raise "No config file #{CONFIG_FILE} readable/found/valid yaml syntax."
end

DB = Sequel.connect(DATABASE_URL)

if CONFIG[:scripts_dir].start_with? "/"
    SCRIPTS_DIR = CONFIG[:scripts_dir]
else
    SCRIPTS_DIR = File.join(File.dirname(__FILE__), CONFIG[:scripts_dir])
end

# Load models
Dir['models/*.rb'].each{|m| require m}

VONECLOUD_VERSION = Version.last
APPLIANCE = Appliance.first

################################################################################
# Start UP tasks
################################################################################

# Resume pending JobQueues
JobQueue.filter(:finished => 0).each do |jobq|
    jobq.run
end

################################################################################
# Routes
################################################################################

helpers do
    def assets(h={})
        js  = h[:js]
        css = h[:css]

        js  = %w(/js/vonecloud.js) if js.nil?
        css = [] if css.nil?

        {
            :js => js,
            :css => css
        }
    end

    def version
        VONECLOUD_VERSION
    end

    def authorized?
        @auth ||=  Rack::Auth::Basic::Request.new(request.env)

        credentials = File.read('/var/lib/one/.one/one_auth').strip.split(':')

        @auth.provided? \
            && @auth.basic? \
            && @auth.credentials \
            && @auth.credentials == credentials
    end

    def check_version
        begin
            uri = CONFIG[:update_url] + "version?uuid=#{APPLIANCE.uuid}&version=#{version.version}"
            uri = URI(uri)

            http = Net::HTTP.new(uri.host, uri.port,
                PROXY['host'], PROXY['port'], PROXY['user'], PROXY['password'])
            http.use_ssl = uri.scheme == 'https'

            res = nil
            http.start {|h| res = h.get(uri.request_uri) }

            res.value
            JSON.parse(res.body)
        rescue Exception => e
            {"error" => e.message}.to_json
        end
    end

    def initial_boot
        Version.where(:bootstrap => true).empty?
    end

    def initial_boot_release
        !Version.where(:bootstrap => true).empty? and !Version.where(:bootstrap => false).empty?
    end

    def next_bootstrap
        Version.where(:bootstrap => 0).min(:version)
    end

    def h(text)
        Rack::Utils.escape_html text
    end

    # This function runs synchronously and therefore blocks the thread. It returns
    # true if OpenNebula is running
    def check_state
        job = Job.create(
            :name => "State",
            :visible => false,
            :body => {
                :cmd => "opennebula-server.sh"
            }
        )

        job.run_sync

        job.success?
    end
end

before do
    unless %w(/version /check_version).include?(request.path)
        headers['WWW-Authenticate'] = 'Basic realm="vOneCloud Control Center Authentication"'
        halt 401 unless authorized?
    end
end

get '/' do
    locals = {
        :page_name => "Dashboard",
        :version   => VONECLOUD_VERSION,
        :appliance => APPLIANCE,
    }
    erb :dashboard, :locals => locals
end

get '/job/:id' do
    id = params[:id]

    job = Job.find(:id => id)

    if job.nil?
        error [404, "Resource not found."]
    end

    locals = {
        :page_name => "Job (##{job[:id]}) #{job[:name]}",
        :job       => job.to_hash,
        :assets    => {
            :css => [],
            :js  => []
        }
    }

    if params[:plain]
        content_type 'text/plain'
        erb :job_plain, :locals => locals, :layout => false
    else
        erb_template = :job
        erb :job, :locals => locals
    end

end

get '/configure' do
    answers = Answers.last[:body] rescue nil

    locals = {
        :page_name => "Configure",
        :assets => {
            :css => ['/css/configure.css'],
            :js  => ['/js/configure.js']
        },
        :answers => answers
    }

    erb :configure, :locals => locals
end

post '/configure' do
    answers = Answers.new(:body => params)

    if !answers.valid?
        locals = {
                :page_name => "Configure",
                :assets => {
                    :css => ['/css/configure.css'],
                    :js  => ['/js/configure.js']
                },
                :answers     => answers.body.to_json,
                :form_errors => answers.errors
            }

        erb :configure, :locals => locals
    else
        answers.save

        jobs = [
            {
                :name => "Reconfigure OpenNebula",
                :body => {
                    :cmd => "reconfigure.rb",
                    :sudo => true
                },
                :success_cb => :reconfigure
            }
        ]

        if check_state
            jobs << {
                :name => "Restart OpenNebula",
                :body => {
                    :cmd => "opennebula-server.sh",
                    :args => ["restart"]
                }
            }
        end

        jobq = JobQueue.create(
            :name => "Apply configuration",
            :jobs => jobs
        )

        jobq.run

        redirect '/'
    end
end

get '/jobs' do
    locals = {
        :page_name => "All Jobs",
        :jobs => Job.filter(:visible => true).reverse
    }

    erb :jobs, :locals => locals
end

get '/logs' do
    logs = Dir["#{LOG_LOCATION}/*"].collect{|l| File.basename l}

    locals = {
        :page_name => "Logs",
        :logs      => logs
    }

    erb :logs, :locals => locals
end

get '/log/:log' do
    content_type 'text/plain'
    log_file = "#{LOG_LOCATION}/#{params[:log]}"

    if File.readable? log_file
        File.read("#{LOG_LOCATION}/#{params[:log]}")
    else
        error [404, "File not found."]
    end
end

################################################################################
# Ajax calls
################################################################################


get '/jobs/:limit' do
    Job.filter(:visible => true).limit(params[:limit]).reverse.collect{|job| job.to_hash }.to_json
end

get '/opennebula_state/:state' do
    state = params[:state].downcase

    error [400, "Invalid data"] if !%w(start stop restart).include?(state)

    if state == "stop"
        job = Job.create(
            :name => "Stop OpenNebula",
            :body => {
                :cmd => "opennebula-server.sh",
                :args => ["stop"]
            }
        )
        job.run
    else # restart and start
        jobs = []
        if state == "restart"
            jobs << {
                :name => "Stop OpenNebula",
                :body => {
                    :cmd => "opennebula-server.sh",
                    :args => ["stop"]
                }
            }
        end

        if next_bootstrap || (Answers.last && !Answers.last.applied)
            jobs << {
                :name => "Reconfigure OpenNebula",
                :body => {
                    :cmd => "reconfigure.rb",
                    :sudo => true
                },
                :success_cb => :reconfigure
            }
        end

        jobs <<  {
            :name => "Start OpenNebula",
            :body => {
                :cmd => "opennebula-server.sh",
                :args => ["start"]
            }
        }

        if next_bootstrap
            jobs << {
                :name => "Bootstrap OpenNebula",
                :body => {
                    :cmd => "vonecloud-bootstrap.rb",
                    :args => [next_bootstrap]
                },
                :success_cb => :bootstrap
            }
        end

        jobq = JobQueue.create(
            :name => "State Change: #{state}",
            :jobs => jobs
        )

        jobq.run
    end

    ""
end

get '/opennebula_state' do
    {
        running: check_state,
        reconfigure: (Answers.last && !Answers.last.applied)
    }.to_json
end

get '/do_upgrade' do
    new_version = check_version

    if new_version["status"].nil? || new_version["status"] != "ok"
        STDERR.puts "Error doing upgrade: #{new_version.inspect}"
        return
    end

    jobq = JobQueue.create(
        :name => "Upgrade #{Time.now}",
        :jobs => [
            {
                :name => "Stop OpenNebula",
                :body => {
                    :cmd => "opennebula-server.sh",
                    :args => ["stop"]
                }
            },
            {
                :name => "Update Packages",
                :body => {
                    :cmd => "update.sh"
                }
            },
            {
                :name => "Restart vOneCloud and Update the DB",
                :body => {
                    :cmd  => "upgrade-db-restart-vonecloud.sh",
                    :args => ["${ID}"],
                    :setsid => true,
                    :stop_queue => true
                }
            },
            {
                :name => "Reconfigure OpenNebula",
                :body => {
                    :cmd => "reconfigure.rb",
                    :sudo => true
                },
                :success_cb => :reconfigure
            },
            {
                :name => "Start OpenNebula",
                :body => {
                    :cmd => "opennebula-server.sh",
                    :args => ["start"]
                }
            },
            {
                :name => "Bootstrap OpenNebula",
                :body => {
                    :cmd  => "vonecloud-bootstrap.rb",
                    :args => [VONECLOUD_VERSION.version, "1"]
                },
                :success_cb => :bootstrap
            }
        ]
    )

    jobq.run

    ""
end

get '/version' do
    VONECLOUD_VERSION.version
end

get '/check_version' do
    check_version.to_json
end

get '/generate_debug' do
    job = Job.create(
        :name => "Debug Info",
        :body => {
            :cmd => "debug-info.sh",
            :args => ["#{FILE_LOCATION}/debug-${ID}.tar.gz"],
            :success_cb_args => ["debug-${ID}.tar.gz"]
        },
        :success_cb => :add_file
    )

    job.run
end

get '/get_file/:id' do
    id = params[:id]

    job = Job.find(:id => id)

    if job.nil?
        error [404, "Resource not found."]
    end

    file = job[:file]

    if file.nil?
        error [404, "File not found."]
    end

    file_path = File.join(FILE_LOCATION, file)

    send_file file_path, :filename => file
end

