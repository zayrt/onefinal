// --------------------------------------------------------------------------
// Copyright 2015, OpenNebula Systems SL
//
// Licensed under the OpenNebula Systems Software License available in a
// text file “LICENSE” as part of the distribution
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//---------------------------------------------------------------------------

//------------------------------------------------------------------------------
// SoftLayer
//------------------------------------------------------------------------------

function add_sl_region(answers){
    var fields = [
        {
            label: "Region Name*",
            field: "<input type='text' data-error-field='region_name' name='sl_region[{{id}}][region_name]' value='{{region_name}}'/>",
            tooltip: "The name of the Softlayer region. Example: ams01, sjc01, dal01, dal02, dal05, etc."
        },
        {
            label: "Default",
            field: "<input type='checkbox' data-error-field='default' name='sl_region[{{id}}][default]' value='{{default}}'/>",
            tooltip: "Select if this is the default region. If more than one is selected, only the first one will be considered default."
        },
        {
            label: "Username*",
            field: "<input type='text' data-error-field='username' name='sl_region[{{id}}][username]' value='{{username}}'/>",
            tooltip: "Username for the Softlayer API."
        },
        {
            label: "API Key*",
            field: "<input type='text' data-error-field='api_key' name='sl_region[{{id}}][api_key]' value='{{api_key}}'/>",
            tooltip: "API key for the Softlayer API."
        },
        {
            label: "Capacity slcci.small*",
            field: "<input type='text' data-error-field='slcci_small' name='sl_region[{{id}}][slcci_small]' placeholder='5' value='{{slcci_small}}'/>",
            tooltip: "Maximum amount of VMs of type slcci.small that can be executed simultaneously."
        },
        {
            label: "Capacity slcci.medium*",
            field: "<input type='text' data-error-field='slcci_medium' name='sl_region[{{id}}][slcci_medium]' placeholder='0' value='{{slcci_medium}}'/>",
            tooltip: "Maximum amount of VMs of type slcci.medium that can be executed simultaneously."
        },
        {
            label: "Capacity slcci.large*",
            field: "<input type='text' data-error-field='slcci_large' name='sl_region[{{id}}][slcci_large]' placeholder='0' value='{{slcci_large}}'/>",
            tooltip: "Maximum amount of VMs of type slcci.large that can be executed simultaneously."
        }
    ];

    var info = {
        key: "sl_region",
        legend: "Softlayer Region",
        fields: fields
    }

    add_multi_resource(answers, info);
}

//------------------------------------------------------------------------------
// Azure
//------------------------------------------------------------------------------

function add_az_global(answers){
    var fields = [
        {
            label: "Proxy URI",
            field: "<input type='text' data-error-field='proxy_uri' name='az_global[proxy_uri]' value='{{proxy_uri}}'/>",
            tooltip: "Proxy address to access Azure API."
        }
    ];

    var info = {
        key: "az_global",
        legend: "Azure Global Options",
        children: "az_region",
        fields: fields
    }

    add_single_resource(answers, info);
}

function add_az_region(answers){
    var fields = [
        {
            label: "Region Name*",
            field: "<input type='text' data-error-field='region_name' name='az_region[{{id}}][region_name]' value='{{region_name}}'/>",
            tooltip: "The name Azure region. Supported: \"West Europe\", \"North Europe\", \"East US\", \"South Central US\", \"West US\", \"East Asia\", \"Southeast Asia\", \"Japan West\", \"Brazil South\". When adding the host to OpenNebula remember to add it in lowercase and with '-' instead of spaces, e.g.: \"South Central US\" => \"south-central-us\"."
        },
        {
            label: "Default",
            field: "<input type='checkbox' data-error-field='default' name='az_region[{{id}}][default]' value='{{default}}'/>",
            tooltip: "Select if this is the default region. If more than one is selected, only the first one will be considered default."
        },
        {
            label: "Pem Management Certificate*",
            field: "<textarea data-error-field='pem_management_cert' name='az_region[{{id}}][pem_management_cert]'>{{pem_management_cert}}</textarea>",
            tooltip: "Select a valid Azure pem management certificate. http://azure.microsoft.com/en-us/documentation/articles/linux-use-ssh-key/"
        },
        {
            label: "Subscription ID*",
            field: "<input type='text' data-error-field='subscription_id' name='az_region[{{id}}][subscription_id]' value='{{subscription_id}}'/>",
            tooltip: "Subscription ID of the Azure API."
        },
        {
            label: "Management Endpoint",
            field: "<input type='text' data-error-field='management_endpoint' name='az_region[{{id}}][management_endpoint]' value='{{management_endpoint}}'/>",
            tooltip: "Management endpoint of the Azure API. If empty it uses the default: https://management.core.windows.net"
        },
        {
            label: "Capacity small*",
            field: "<input type='text' data-error-field='small' name='az_region[{{id}}][small]' placeholder='5' value='{{small}}'/>",
            tooltip: "Maximum amount of VMs of type small that can be executed simultaneously."
        },
        {
            label: "Capacity medium*",
            field: "<input type='text' data-error-field='medium' name='az_region[{{id}}][medium]' placeholder='1' value='{{medium}}'/>",
            tooltip: "Maximum amount of VMs of type m1.large that can be executed simultaneously."
        },
        {
            label: "Capacity large*",
            field: "<input type='text' data-error-field='large' name='az_region[{{id}}][large]' placeholder='0' value='{{large}}'/>",
            tooltip: "Maximum amount of VMs of type large that can be executed simultaneously."
        }
    ];

    var info = {
        key: "az_region",
        legend: "Azure Region",
        fields: fields
    }

    add_multi_resource(answers, info);
}

//------------------------------------------------------------------------------
// EC2
//------------------------------------------------------------------------------

function add_ec2_global(answers){
    var fields = [
        {
            label: "Proxy URI",
            field: "<input type='text' data-error-field='proxy_uri' name='ec2_global[proxy_uri]' value='{{proxy_uri}}'/>",
            tooltip: "Proxy address to access EC2 API."
        }
    ];

    var info = {
        key: "ec2_global",
        legend: "EC2 Global Options",
        children: "ec2_region",
        fields: fields
    }

    add_single_resource(answers, info);
}

function add_ec2_region(answers){
    var fields = [
        {
            label: "Region Name*",
            field: "<input type='text' data-error-field='region_name' name='ec2_region[{{id}}][region_name]' value='{{region_name}}'/>",
            tooltip: "The name EC2 region. Example: us-east-1, us-west-2, ap-southeast-2, etc."
        },
        {
            label: "Default",
            field: "<input type='checkbox' data-error-field='default' name='ec2_region[{{id}}][default]' value='{{default}}'/>",
            tooltip: "Select if this is the default region. If more than one is selected, only the first one will be considered default."
        },
        {
            label: "Access Key ID*",
            field: "<input type='text' data-error-field='access_key_id' name='ec2_region[{{id}}][access_key_id]' value='{{access_key_id}}'/>",
            tooltip: "Access Key ID to interact with the EC2 API."
        },
        {
            label: "Secret Access Key*",
            field: "<input type='text' data-error-field='secret_access_key' name='ec2_region[{{id}}][secret_access_key]' value='{{secret_access_key}}'/>",
            tooltip: "Secret Access Key to interfact with the EC2 API."
        },
        {
            label: "Capacity m1.small*",
            field: "<input type='text' data-error-field='m1_small' name='ec2_region[{{id}}][m1_small]' placeholder='5' value='{{m1_small}}'/>",
            tooltip: "Maximum amount of VMs of type m1.small that can be executed simultaneously."
        },
        {
            label: "Capacity m1.large*",
            field: "<input type='text' data-error-field='m1_large' name='ec2_region[{{id}}][m1_large]' placeholder='0' value='{{m1_large}}'/>",
            tooltip: "Maximum amount of VMs of type m1.large that can be executed simultaneously."
        },
        {
            label: "Capacity m1.xlarge*",
            field: "<input type='text' data-error-field='m1_xlarge' name='ec2_region[{{id}}][m1_xlarge]' placeholder='0' value='{{m1_xlarge}}'/>",
            tooltip: "Maximum amount of VMs of type m1.xlarge that can be executed simultaneously."
        },
    ];

    var info = {
        key: "ec2_region",
        legend: "EC2 Region",
        fields: fields
    }

    add_multi_resource(answers, info);
}

//------------------------------------------------------------------------------
// LdapServer
//------------------------------------------------------------------------------

function add_ldapserver(answers){
    var fields = [
        {
            label: "Server Name*",
            field: "<input type='text' data-error-field='servername' name='ldapserver[{{id}}][servername]' value='{{servername}}'/>",
            tooltip: "The name of the Active Directory / Ldap Server"
        },
        {
            label: "User",
            field: "<input type='text' data-error-field='user' name='ldapserver[{{id}}][user]' value='{{user}}'/>",
            tooltip: "Active Directory user able to query, if not set connects as anonymous. For Active Directory append the domain name. Example: Administrator@my.domain.com"
        },
        {
            label: "Password",
            field: "<input type='password' data-error-field='password' name='ldapserver[{{id}}][password]' value='{{password}}'/>",
            tooltip: "Password if the Active Directory user able to query"
        },
        {
            label: "Authentication method*",
            field: "<input type='text' data-error-field='auth_method' name='ldapserver[{{id}}][auth_method]' placeholder='simple' value='{{auth_method}}'/>",
            tooltip: "Select the autentication method: simple or simple_tls"
        },
        {
            label: "Encryption",
            field: "<input type='text' data-error-field='encryption' name='ldapserver[{{id}}][encryption]' value='{{encryption}}'/>",
            tooltip: "Leave blank for non-tls, or use simple_tls if tls is enabled."
        },
        {
            label: "Host*",
            field: "<input type='text' data-error-field='host' name='ldapserver[{{id}}][host]' placeholder='localhost' value='{{host}}'/>",
            tooltip: "Address of the Active Directory Server"
        },
        {
            label: "Port*",
            field: "<input type='text' data-error-field='port' name='ldapserver[{{id}}][port]' placeholder='389' value='{{port}}'/>",
            tooltip: "Port of the Active Directory server"
        },
        {
            label: "Base Domain*",
            field: "<input type='text' data-error-field='base' name='ldapserver[{{id}}][base]' placeholder='dc_domain' value='{{base}}'/>",
            tooltip: "Base hierarchy where to search for users and groups"
        },
        {
            label: "Group",
            field: "<input type='text' data-error-field='group' name='ldapserver[{{id}}][group]' value='{{group}}'/>",
            tooltip: "Group the users need to belong to. If not set any user will do. Example: cn=cloud,ou=groups,dc=domain"
        },
        {
            label: "User Field",
            field: "<input type='text' data-error-field='user_field' name='ldapserver[{{id}}][user_field]' placeholder='cn' value='{{user_field}}'/>",
            tooltip: "Field that holds the user name. For Active Directory use this user_field instead: sAMAccountName"
        },
        {
            label: "Group Field",
            field: "<input type='text' data-error-field='group_field' name='ldapserver[{{id}}][group_field]' placeholder='member' value='{{group_field}}'/>",
            tooltip: "Field name for group membership, by default it is 'member'"
        },
        {
            label: "User Group Field",
            field: "<input type='text' data-error-field='user_group_field' name='ldapserver[{{id}}][user_group_field]' placeholder='user_group_field' value='{{user_group_field}}'/>",
            tooltip: "User field that that is in in the group group_field, if not set 'dn' will be used"
        }
    ];

    var info = {
        key: "ldapserver",
        legend: "Active Directory Server",
        fields: fields
    }

    add_multi_resource(answers, info);
}

//------------------------------------------------------------------------------
// Lib
//------------------------------------------------------------------------------

function add_single_resource(answers, info){
    var key      = info["key"];
    var children = info["children"];
    var fields   = info["fields"];
    var legend   = info["legend"];


    if ($('#'+key+'-single').length > 0)
        return;

    var form = "\
    <fieldset id='{{key}}-single' name='{{key}}' data-children='{{children}}'>\
        <legend>{{legend}}</legend>\
        {{#fields}}\
            <div class='row'>\
                <label><span data-tooltip aria-haspopup='true' class='has-tip' title='{{tooltip}}'>{{label}}</span>\
                    {{{field_s}}}\
                </label>\
            </div>\
        {{/fields}}\
        </div>\
    </fieldset>";

    var rendered = "";

    var element;
    if (answers && answers[key]) {
        element = answers[key];
    } else if (typeof(answers) == 'undefined'){
        element = {};
    }

    if (element){
        var vars = {
            key: key,
            fields: fields,
            children: children,
            legend: legend,
            field_s: function() {
                return Mustache.to_html(this.field, element);
            }
        }

        rendered += Mustache.render(form, vars);

        $("#"+key).html(rendered);
    }
}


function add_multi_resource(answers, info){
    var key      = info["key"];
    var fields   = info["fields"];
    var legend   = info["legend"];

    var form = "\
    <fieldset id='{{key}}-{{id}}' name='{{key}}-{{id}}'>\
        <legend>{{legend}}</legend>\
        <div class='row'>\
            <div class='large-12 columns'>\
                {{#fields}}\
                    <div class='row'>\
                        <label><span data-tooltip aria-haspopup='true' class='has-tip' title='{{tooltip}}'>{{label}}</span>\
                            {{{field_s}}}\
                        </label>\
                    </div>\
                {{/fields}}\
                <br/>\
                <div class='right'>\
                    <button class='alert remove_fieldset'>Remove {{legend}}</button>\
                </div>\
            </div>\
        </div>\
    </fieldset>";

    var rendered = "";

    if (answers && answers[key]) { // render existing items

        $.each(answers[key],function(id, element){

            element["id"] = id;

            // var
            var vars = {
                id: id,
                key: key,
                legend: legend,
                fields: fields,
                field_s: function() {
                    return Mustache.to_html(this.field, element);
                }
            }

            rendered += Mustache.render(form, vars);
        });

    } else if (typeof(answers) == 'undefined') { // render empty item

        var id = get_fieldset_id(key);

        // vars
        var vars = {
            id: id,
            key: key,
            legend: legend,
            fields: fields,
            field_s: function() {
                return Mustache.to_html(this.field, {id: id});
            }
        }

        // render
        rendered += Mustache.render(form, vars);
    }

    $("#"+key).append(rendered);
}

function get_fieldset_id(key){
    var id;
    var indexes = $.map($("#"+key+" *[name^='"+key+"[']"),function(e){
        var r = new RegExp(key + "\\[(.*?)\\]");
        return $(e).attr('name').match(r).pop();
    });

    if (indexes.length > 0){
        id = Math.max.apply(null, indexes) + 1;
    } else {
        id = 0;
    }

    return id;
}

function display_errors(form_errors){
    $.each(form_errors, function(i,e){
        var fieldset = e["fieldset"];
        var field = e["field"];
        var msg = e["message"];

        var error_div_id = "error-"+fieldset;

        var input = $("#"+fieldset+" [data-error-field='"+field+"']");

        // create div for errors if it doesn't exist
        if ($("#"+error_div_id).length == 0){
            $("#"+fieldset).prepend("<ul id='"+error_div_id+"' class='errors'></ul>")
        }

        input.addClass('error_field');

        var field_name = input.parents("label").text().replace(/\*$/,"");
        $("#"+error_div_id).append("<li>"+field_name+": "+msg+"</li>");
    });
}

//------------------------------------------------------------------------------
// Main
//------------------------------------------------------------------------------

$(document).ready(function(){
    add_ldapserver(answers);
    //add_ec2_global(answers);
    add_ec2_region(answers);
    //add_az_global(answers);
    add_az_region(answers);
    add_sl_region(answers);

    // listeners

    $("#configure_form").on("click",".alert.remove_fieldset", function(){
        var key = $(this).parents("fieldset").attr('name').replace(/-\d+$/,"");
        $(this).parents('fieldset').remove();

        if (get_fieldset_id(key) == 0){
            $("fieldset[data-children]").each(function(_,e){
                var children = $(e).attr('data-children');

                if (children.match(new RegExp("\\b"+key+"\\b")))
                    $(e).remove();
            });
        }
        return false;
    });

    $("#configure_form").on("click",".add_fieldset", function(){
        switch ($(this).attr('data-fieldset-key')) {
            case "ldapserver":
                add_ldapserver();
                break;
            case "ec2_region":
                //add_ec2_global();
                add_ec2_region();
                break;
            case "az_region":
                //add_az_global();
                add_az_region();
                break;
            case "sl_region":
                add_sl_region();
                break;
        }

        return false;
    });

    // display errors
    if (typeof(form_errors) != 'undefined'){
        display_errors(form_errors);
    }
});
