// --------------------------------------------------------------------------
// Copyright 2015, OpenNebula Systems SL
//
// Licensed under the OpenNebula Systems Software License available in a
// text file “LICENSE” as part of the distribution
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//---------------------------------------------------------------------------

var jobs;

function refresh_jobs() {
    $.getJSON("/jobs/8")
    .done(function(data){
        var jobs_div = "";

        var job_template = "\
            <tr>\
                <td>\
                    <a href='/job/{{id}}'>{{name}}</a><br/>\
                    <span class='task_timestamp'>{{created_at}}</span>\
                </td>\
                <td>\
                    <a href='/job/{{id}}'><span class='label round {{state_class}}'>{{state}}</span></a>\
                </td>\
            </tr>\
        ";

        $.each(data,function(_,job){
            var state;
            var state_class;


            switch (job["state"]){
            case "finished":
                if (job["success"]){
                    state_class = "success";
                    state = "success";
                } else {
                    state_class = "alert";
                    state = "fail";
                }
                break;
            case "running":
                state = job["state"];
                state_class = "";
                break;
            case "pending":
                state = job["state"];
                state_class = "secondary";
                break;
            case "cancelled":
                state = 'cancel';
                state_class = "secondary";
                break;
            }

            var vars = {
                id: job['id'],
                name: job['name'],
                created_at: job['created_at'],
                state_class: state_class,
                state: state
            }

            jobs_div += Mustache.render(job_template, vars);
        })

        if (JSON.stringify(jobs) != JSON.stringify(data)) {
            $("#jobs").html(jobs_div);
            jobs = data;
            refresh_opennebula_state();
            refresh_version();
        }
    });
}

function refresh_version() {
    $.get("/version")
    .done(function(new_vonecloud_version){
        if (new_vonecloud_version != vonecloud_version) {
            window.location.href = "/";
        }
    });
}

function refresh_opennebula_state() {
    $.getJSON("/opennebula_state")
    .done(function(data){
        if (data['running']) {
            $("#opennebula_state_off").hide();
            $("#opennebula_state_on").show();
        } else {
            $("#opennebula_state_off").show();
            $("#opennebula_state_on").hide();
        }

        if (data['reconfigure'] && data['running']) {
            $("#opennebula_state_reconfigure").show();
        } else {
            $("#opennebula_state_reconfigure").hide();
        }
    });
}

function opennebula_state_change(e) {
    var state = $(e).text();

    $.get("/opennebula_state/"+state)
    .done(refresh_jobs());
}

function do_upgrade() {
    $.get('/do_upgrade');
}

function check_version(){
    $.getJSON('/check_version')
    .done(function(data){
        $(".upgrade_div").hide();

        if (typeof(data['status']) == 'undefined') {
            // Connection Error
            $("#version_no_conn").show();
            console.log(JSON.stringify(data));
            return true;
        }

        if (data['new_version']) {
            $(".new_version").html(data['version']);
            if (data['description']){
                $(".version_description").css('margin-top','20px');
                $(".version_description").html(data['description']);
            }
            $("#version_new").show();
        } else {
            $("#version_up_to_date").show();
        }

        if (data['version'] > vonecloud_version && data['status'] == 'ok') {
            $("#subs_active_do_upgrade").show();
        } else if (data['errno'] == 1) {
            // No susbcription
            $("#subs_no").show();
        } else if (data['errno'] == 2) {
            // Expired
            $("#subs_expired").show();
        }

    }).fail(function(data){
        $(".upgrade_div").hide();
        $("#version_no_conn").show();
        console.log(JSON.stringify(data));
    });
}

function generate_debug() {
    $.get('/generate_debug');
}

$( document ).ready(function() {
    // set up listeners
    $("body").on("click","a.opennebula_state_change",function(){
        opennebula_state_change(this);
    });

    $("body").on("click","span.do_upgrade",function(){
        window.scrollTo(0,0);
        $('#upgrade_confirm').foundation('reveal', 'open');
    });

    $("#upgrade_confirm").on("click", ".upgrade_confirm_cancel", function(){
        $('#upgrade_confirm').foundation('reveal', 'close');
    });

    $("#upgrade_confirm").on("click", ".upgrade_confirm_ok", function(){
        do_upgrade();
        $('#upgrade_confirm').foundation('reveal', 'close');
    });

    $("body").on("click",".click_close_row",function(){
        $(this).parents(".initial_boot_info").hide();
    });

    $("body").on("click",".generate_debug",function(){
        generate_debug();
    });

    // Info refresh
    refresh_jobs();
    check_version();
    setInterval(function(){refresh_jobs()}, 1000);
    setInterval(function(){check_version()}, 60*60*1000);
});
