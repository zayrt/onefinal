# -------------------------------------------------------------------------- #
# Copyright 2015, OpenNebula Systems SL                                      #
#                                                                            #
# Licensed under the OpenNebula Systems Software License available in a      #
# text file “LICENSE” as part of the distribution                            #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'uuidtools'

Sequel.migration do
    VERSION = "1.2"

    up do
        create_table(:appliance) do
            String :uuid, :size => 36, :null => false
            DateTime :date, :null => false
        end

        create_table(:versions) do
            primary_key :id
            String :version, :size => 20, :null => false
            DateTime :date, :null => false
            TrueClass :bootstrap, :default => false
        end

        create_table(:jobs) do
            primary_key :id
            String :name
            String :body, :text=>true
            String :cmdline, :text=>true
            String :stdout, :text=>true
            String :stderr, :text=>true
            String :success_cb
            Integer :pid
            Integer :exit_status
            DateTime :created_at, :null => false
            DateTime :start_time
            DateTime :end_time
            TrueClass :visible, :default => true
            TrueClass :cancelled, :default => false
        end

        create_table(:job_queues) do
            primary_key :id
            String :name
            String :jobs, :text=>true
            DateTime :created_at, :null => false
            TrueClass :finished, :default => false
        end

        create_table(:answers) do
            primary_key :id
            String :body, :text=>true, :null => false
            String :version, :size => 20, :null => false
            DateTime :created_at, :null => false
            TrueClass :applied, :default => false
        end

        uuid = UUIDTools::UUID.random_create.to_s
        self[:appliance].insert(:uuid => uuid, :date => Time.now)

        self[:versions].insert(:version => VERSION, :date => Time.now)

        self[:answers].insert(:body=>'{}', :version=> VERSION, :created_at => Time.now)
    end

    down do
        drop_table(:appliance)
        drop_table(:versions)
        drop_table(:jobs)
        drop_table(:job_queues)
        drop_table(:answers)
    end
end
