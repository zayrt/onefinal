# -------------------------------------------------------------------------- #
# Copyright 2002-2015, OpenNebula Project (OpenNebula.org), C12G Labs        #
#                                                                            #
# Licensed under the Apache License, Version 2.0 (the "License"); you may    #
# not use this file except in compliance with the License. You may obtain    #
# a copy of the License at                                                   #
#                                                                            #
# http://www.apache.org/licenses/LICENSE-2.0                                 #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'OpenNebulaJSON/JSONUtils'

module OpenNebulaJSON
    class UserJSON < OpenNebula::User
        include JSONUtils

        def insert_mail(user_hash)
            uid = 0
            $db.fetch("SELECT oid FROM user_pool WHERE name='#{user_hash["name"]}'") do |row|
                uid = row[:oid]
            end
            $db.run(
                "INSERT INTO user_annexe (user_id, email, manager_name, manager_email, job) "<<
                "VALUES ("                               <<
                "'#{uid}', "                <<
                "'#{user_hash["email"]}', " <<
                "'#{user_hash["manager_name"]}', " <<
                "'#{user_hash["manager_email"]}', " <<
                "'#{user_hash["job"]}')"
            )
        end

        def validation_mail(user_hash)
            email = ""
            $db.fetch("SELECT email FROM user_annexe WHERE email='#{user_hash["email"]}'") do |row|
                email = row[:email]
            end
            if user_hash["email"].match(/\A[\w+\-.]+@[a-z\d\-]+(\.[a-z]+)*\.[a-z]+\z/i).nil?
                return [500, OpenNebula::Error.new("[UserAllocate] Error allocating a new user. Invalid user email, it isn't an email format.")]
            elsif user_hash["manager_email"].match(/\A[\w+\-.]+@[a-z\d\-]+(\.[a-z]+)*\.[a-z]+\z/i).nil?
                return [500, OpenNebula::Error.new("[UserAllocate] Error allocating a new user. Invalid manager email. Error format.")]
            elsif email == user_hash["email"]
                return [500, OpenNebula::Error.new("[UserAllocate] Error allocating a new user. Invalid user email. Email is already taken.")]
            elsif user_hash["manager_name"].match(/\A[a-zA-Z0-9]+\z/).nil?
                return [500, OpenNebula::Error.new("[UserAllocate] Error allocating a new user. Invalid manager name. Error format.")]
            elsif user_hash["job"] == ""
                return [500, OpenNebula::Error.new("[UserAllocate] Error allocating a new user. Invalid Job. Can't be empty.")]
            end
            return [200, "ok"]
        end

        def create(template_json)
            user_hash = parse_json(template_json, 'user')
            
            if OpenNebula.is_error?(user_hash)
                return user_hash
            end
            r = validation_mail(user_hash)
            if r[0] != 200
                return r[1]
            end

            r = self.allocate(user_hash['name'],
                          user_hash['password'],
                          user_hash['auth_driver'])
            insert_mail(user_hash)
            r
        end

        def delete()
            
        end

        def perform_action(template_json)
            action_hash = parse_json(template_json, 'action')
            if OpenNebula.is_error?(action_hash)
                return action_hash
            end

            rc = case action_hash['perform']
                 when "passwd"       then self.passwd(action_hash['params'])
                 when "chgrp"        then self.chgrp(action_hash['params'])
                 when "chauth"       then self.chauth(action_hash['params'])
                 when "update"       then self.update(action_hash['params'])
                 when "set_quota"    then self.set_quota(action_hash['params'])
                 when "addgroup"     then self.addgroup(action_hash['params'])
                 when "delgroup"     then self.delgroup(action_hash['params'])
                 else
                     error_msg = "#{action_hash['perform']} action not " <<
                         " available for this resource"
                     OpenNebula::Error.new(error_msg)
                 end
        end

        def passwd(params=Hash.new)
            super(params['password'])
        end

        def chgrp(params=Hash.new)
            super(params['group_id'].to_i)
        end

        def chauth(params=Hash.new)
            super(params['auth_driver'])
        end

        def update(params=Hash.new)
            super(params['template_raw'])
        end

        def set_quota(params=Hash.new)
            quota_json = params['quotas']
            quota_template = template_to_str(quota_json)
            super(quota_template)
        end

        def addgroup(params=Hash.new)
            super(params['group_id'].to_i)
        end

        def delgroup(params=Hash.new)
            super(params['group_id'].to_i)
        end

    end
end
