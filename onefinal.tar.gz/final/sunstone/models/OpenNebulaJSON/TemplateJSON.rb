# -------------------------------------------------------------------------- #
# Copyright 2002-2015, OpenNebula Project (OpenNebula.org), C12G Labs        #
#                                                                            #
# Licensed under the Apache License, Version 2.0 (the "License"); you may    #
# not use this file except in compliance with the License. You may obtain    #
# a copy of the License at                                                   #
#                                                                            #
# http://www.apache.org/licenses/LICENSE-2.0                                 #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'OpenNebulaJSON/JSONUtils'
require VAR_LOCATION + '/remotes/vmm/numergy_vmware/num_vmware_driver'
require VAR_LOCATION + '/remotes/vmm/numergy_openstack/num_openstack_driver'

module OpenNebulaJSON
    def getname_driver(host_id)
        body = nil
        $db.fetch("SELECT body FROM host_pool WHERE oid='#{host_id}'") do |row|
            body = row[:body]
        end
        d = REXML::Document.new body
        unless  d.elements["HOST"].nil? || d.elements["HOST"].elements["IM_MAD"].nil?
            name_driver = d.elements["HOST"].elements["IM_MAD"].text.split('"').last
        end
        name_driver
    end

    class TemplateJSON < OpenNebula::Template
        include JSONUtils

        def create(template_json)
            template_hash = parse_json(template_json, 'vmtemplate')
            if OpenNebula.is_error?(template_hash)
                return template_hash
            end

            if template_hash['template_raw']
                template = template_hash['template_raw']
            else
                template = template_to_str(template_hash)
            end

            self.allocate(template)
       end

       def perform_action(template_json)
            action_hash = parse_json(template_json, 'action')
            if OpenNebula.is_error?(action_hash)
                return action_hash
            end

            rc = case action_hash['perform']
                 when "publish"     then self.publish
                 when "unpublish"   then self.unpublish
                 when "update"      then self.update(action_hash['params'])
                 when "chown"       then self.chown(action_hash['params'])
                 when "chmod"       then self.chmod_json(action_hash['params'])
                 when "instantiate" then self.instantiate(action_hash['params'])
                 when "clone"       then self.clone(action_hash['params'])
                 when "rename"      then self.rename(action_hash['params'])
                 else
                     error_msg = "#{action_hash['perform']} action not " <<
                         " available for this resource"
                     OpenNebula::Error.new(error_msg)
                 end
        end

        def update(params=Hash.new)
            template_hash = parse_json(params, 'vmtemplate')
            if template_hash['template_raw']
                template = template_hash['template_raw']
            else
                template = template_to_str(template_hash)
            end

            super(template)
        end

        def chown(params=Hash.new)
            super(params['owner_id'].to_i,params['group_id'].to_i)
        end

        def chmod_json(params=Hash.new)
            if params['octet']
                self.chmod_octet(params['octet'])
            else
                self.chmod((params['owner_u']||-1),
                    (params['owner_m']||-1),
                    (params['owner_a']||-1),
                    (params['group_u']||-1),
                    (params['group_m']||-1),
                    (params['group_a']||-1),
                    (params['other_u']||-1),
                    (params['other_m']||-1),
                    (params['other_a']||-1))
            end
        end
        
        def handle_num_instantiate(params)
            id = nil
            id_num = nil
            host_id = nil 
            $db.fetch("SELECT oid FROM vm_pool WHERE name='#{params['vm_name']}'") do |row|
                id = row[:oid]
            end
            if !id.nil?
                return [500, OpenNebula::Error.new("[VmInstantiate] Error VM name already exist.")]
            end
            body = nil
            $db.fetch("SELECT body FROM template_pool WHERE oid='#{$template_params[:id]}'") do |row|
                body = row[:body]
            end
            d = REXML::Document.new body
            unless  d.elements["VMTEMPLATE"].nil? || d.elements["VMTEMPLATE"].elements["TEMPLATE"].nil? || d.elements["VMTEMPLATE"].elements["TEMPLATE"].elements["SCHED_REQUIREMENTS"].nil?
                host_id = d.elements["VMTEMPLATE"].elements["TEMPLATE"].elements["SCHED_REQUIREMENTS"].text.split('"').last.to_i
            end
            name_driver = getname_driver(host_id)
            if name_driver == "num_vmware" || name_driver == "num_os"
                $db.fetch("SELECT host_id_num FROM host_annexe WHERE host_id='#{host_id}'") do |row|
                    id_num = row[:host_id_num]
                end
            end 
            if name_driver == "num_vmware"
                res = $num_driver.generate_key(id_num)
                if res[0] != "200"
                    return [500, OpenNebula::Error.new(res[1])]
                end
                key = JSON.parse(res[2])
                env_params = $num_conf["numergy_env_params"]
                vm_params = $num_conf["vm_params"]
                dest_env = NumergyDriver.new(env_params["version_api_id"], key["tenant"]["id"],key["accessKeyCredentials"]["accessKey"], key["accessKeyCredentials"]["secretKey"])
                vm_params["server"]["name"] = params["vm_name"]
                res = dest_env.createResource("servers", vm_params)
                if res[0] != "200"
                    return [500, OpenNebula::Error.new(res[1])]
                end
                return [JSON.parse(res[2])["server"]["id"], id_num, "num_vmware"]
            elsif name_driver == "num_os"
                vm_params = $num_os_conf["vm_params"]
                vm_params["server"]["name"] = params["vm_name"]
                res = $num_os_driver.createResource("compute/v2/#{id_num}/servers", vm_params)
                STDERR.puts vm_params.inspect
                STDERR.puts id_num.inspect
                if res[0] != "202"
                    return [500, OpenNebula::Error.new(res[1])]
                end
                return [JSON.parse(res[2])["server"]["id"], id_num, "num_os"]
            end
            return ""
        end

        def instantiate(params=Hash.new)
            server_num_info = handle_num_instantiate(params)
            if server_num_info[0] == 500
                return server_num_info[1]
            end
            if params['template']
                select_capacity = self['TEMPLATE/SUNSTONE_CAPACITY_SELECT']
                if (select_capacity && select_capacity.upcase == "NO")
                    params['template'].delete("CPU")
                    params['template'].delete("MEMORY")
                end
                
                select_network = self['TEMPLATE/SUNSTONE_NETWORK_SELECT']
                if (select_network && select_network.upcase == "NO")
                    params['template'].delete("NIC")
                end
                
                template = template_to_str(params['template'])
                ret = super(params['vm_name'], params['hold'], template)
            else
                ret = super(params['vm_name'], params['hold'])
            end
            id = nil
            $db.fetch("SELECT oid FROM vm_pool WHERE name='#{params['vm_name']}'") do |row|
                id = row[:oid]
            end
            if !id.nil?
                $db.run("INSERT vm_annexe (vm_id, num_id, tenant_id, driver_numergy, project) " <<
                        "VALUES (" <<
                        "'#{id}', " <<
                        "'#{server_num_info[0]}', " <<
                        "'#{server_num_info[1]}', " <<
                        "'#{server_num_info[2]}', " <<
                        "'#{params['vm_project']}')" )
            end
            ret
        end

        def clone(params=Hash.new)
            super(params['name'])
        end

        def rename(params=Hash.new)
            super(params['name'])
        end
    end
end
