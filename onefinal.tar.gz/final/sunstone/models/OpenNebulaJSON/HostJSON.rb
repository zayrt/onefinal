# -------------------------------------------------------------------------- #
# Copyright 2002-2015, OpenNebula Project (OpenNebula.org), C12G Labs        #
#                                                                            #
# Licensed under the Apache License, Version 2.0 (the "License"); you may    #
# not use this file except in compliance with the License. You may obtain    #
# a copy of the License at                                                   #
#                                                                            #
# http://www.apache.org/licenses/LICENSE-2.0                                 #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

require 'OpenNebulaJSON/JSONUtils'

module OpenNebulaJSON
    class HostJSON < OpenNebula::Host
        include JSONUtils

        def handle_numergy(host_hash)
            id = nil
            tenant_params = $num_conf["environnement_params"]
            project_params = $num_os_conf["project_os_params"]
            $db.fetch("SELECT oid FROM host_pool WHERE name='#{host_hash["name"]}'") do |row|
                id = row[:oid]
            end
            if !id.nil?
                return [500, OpenNebula::Error.new("[HostAllocate] Error name already taken.")]
            end

            if host_hash["vm_mad"] == "num_vmware" && host_hash["im_mad"] == "num_vmware"
                tenant_params["tenant"]["name"] = host_hash["name"]
                ret = $num_driver.createResource("N-RADM/tenants", tenant_params)
                if ret[0] != "200"
                    return [500, OpenNebula::Error.new("[HostAllocate] Error #{ret[1]}.")]
                end
                id = JSON.parse(ret[2])["tenant"]["id"]
            elsif host_hash["vm_mad"] == "num_os" && host_hash["im_mad"] == "num_os"
                project_params["name"] = host_hash["name"]
                ret = $num_os_driver.createResource("api/projects", project_params)
                if ret[0] != "202"
                    return [500, OpenNebula::Error.new("[HostAllocate] Error.")]
                end
                id = JSON.parse(ret[2])["id"] 
            end
            [200, id]
        end

        def insert_numergy_annexe(host_hash, num_id)
            if host_hash["im_mad"] == "num_vmware" || host_hash["im_mad"] == "num_os"
                id = nil
                $db.fetch("SELECT oid FROM host_pool WHERE name='#{host_hash["name"]}'") do |row|
                    id = row[:oid]
                end
                $db.run("INSERT host_annexe (host_id_num, host_id, name) " <<
                    "VALUES ("                                               <<
                    "'#{num_id}', "                                          <<
                    "'#{id}', "                                              <<
                    "'#{host_hash["name"]}')"
                )
            end
        end

        def create(template_json)
            host_hash = parse_json(template_json, 'host')
            
            if OpenNebula.is_error?(host_hash)
                return host_hash
            end
            
            r = handle_numergy(host_hash)
            if r[0] == 500
                return r[1]
            end
            
            ret = self.allocate(host_hash['name'],
                          host_hash['im_mad'],
                          host_hash['vm_mad'],
                          host_hash['vnm_mad'],
                          host_hash['cluster_id'].to_i)
            
            insert_numergy_annexe(host_hash, r[1])
            ret
        end

        def delete
            if self['HOST_SHARE/RUNNING_VMS'].to_i != 0
                OpenNebula::Error.new("Host still has associated VMs, aborting delete.")
            else
                super
            end
        end

        def perform_action(template_json)
            action_hash = parse_json(template_json, 'action')
            if OpenNebula.is_error?(action_hash)
                return action_hash
            end

            rc = case action_hash['perform']
                when "enable"  then self.enable
                when "disable" then self.disable
                when "update" then self.update(action_hash['params'])
                when "rename" then self.rename(action_hash['params'])
                else
                    error_msg = "#{action_hash['perform']} action not " <<
                                " available for this resource"
                    OpenNebula::Error.new(error_msg)
            end
        end

        def update(params=Hash.new)
            super(params['template_raw'])
        end

        def rename(params=Hash.new)
            super(params['name'])
        end
    end
end
