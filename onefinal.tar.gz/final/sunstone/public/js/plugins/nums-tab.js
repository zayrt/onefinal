/* -------------------------------------------------------------------------- */
/* Copyright 2002-2015, OpenNebula Project (OpenNebula.org), C12G Labs        */
/*                                                                            */
/* Licensed under the Apache License, Version 2.0 (the "License"); you may    */
/* not use this file except in compliance with the License. You may obtain    */
/* a copy of the License at                                                   */
/*                                                                            */
/* http://www.apache.org/licenses/LICENSE-2.0                                 */
/*                                                                            */
/* Unless required by applicable law or agreed to in writing, software        */
/* distributed under the License is distributed on an "AS IS" BASIS,          */
/* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   */
/* See the License for the specific language governing permissions and        */
/* limitations under the License.                                             */
/* -------------------------------------------------------------------------- */

/* ---------------- Num tab plugin ---------------- */

var dataTable_nums;

//setup actions

var num_actions = {
        
    "Num.refresh" : {
        type: "custom",
        call: getNumList,
        error: onError
    },
    "Num.list" : {
        call: getNumList
    }
};

function numElementArray(element){
    parts = element.date_num.split(" ");
    element.date_num = parts[0] + " " + parts[1];
    return [
        element.id,
        element.date_num,
        element.numin
    ];
}

function getNumList() {
    var list_array = [];
    $.ajax({
        url: "https://api.github.com/",
        type: "GET",
        //dataType: "json",
        /* contentType: "application/json; charset=utf-8",
        crossDomain: true,
        xhrFields: {
            withCredentials: true
        }, */
        success: function (response) {
            //console.log(JSON.stringify(response));
            /*$.each(response, function(index, element) {
                list_array.push(numElementArray(element));
            });
            updateView(list_array, dataTable_nums);*/
        },
        error: function (response) {
            console.num("error");
        }
    });
}

var num_buttons = {
    "Num.refresh" : {
        type: "action",
        layout: "refresh",
        alwaysActive: true
    }
};

var nums_tab = {
    title: tr("Nums"),
    resource: 'Num',
    buttons: num_buttons,
    tabClass: "subTab",
    parentTab: "system-tab",
    search_input: '<input id="num_search" type="search" placeholder="'+tr("Search")+'" />',
    list_header: '<i class="fa fa-fw fa-laptop"></i>&emsp;'+tr("Nums"),
    subheader: '<span/> <small></small>&emsp;',
    table: '<table id="datatable_nums" class="datatable twelve">\
        <thead>\
          <tr>\
            <th>' + tr("ID") + '</th>\
            <th>' + tr("DateTimes") + '</th>\
            <th>' + tr("Name") + '</th>\
          </tr>\
        </thead>\
        <tbody id="tbodynums">\
        </tbody>\
      </table>'
};

Sunstone.addActions(num_actions);
Sunstone.addMainTab('nums-tab',nums_tab);

$(document).ready(function(){
        var tab_name = "nums-tab"
        if (Config.isTabEnabled(tab_name)){
            dataTable_nums = $("#datatable_nums",main_tabs_context).dataTable({
                "bSortClasses": false,
                "bDeferRender": true,
                "aoColumnDefs": [
                    { "bSortable": false, "aTargets": ["check"] },
                    { "sWidth": "35px", "aTargets": [0] },
                    { "bVisible": true, "aTargets": Config.tabTableColumns(tab_name)},
                    { "bVisible": false, "aTargets": ['_all']}
                ]
            });

            $('#num_search').keyup(function(){
                dataTable_nums.fnFilter( $(this).val() );
            })

            getNumList();
            dataTable_nums.fnSort( [ [1,config['user_config']['table_order']] ] );
        }
});
