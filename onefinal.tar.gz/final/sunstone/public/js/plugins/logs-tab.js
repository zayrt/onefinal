/* -------------------------------------------------------------------------- */
/* Copyright 2002-2015, OpenNebula Project (OpenNebula.org), C12G Labs        */
/*                                                                            */
/* Licensed under the Apache License, Version 2.0 (the "License"); you may    */
/* not use this file except in compliance with the License. You may obtain    */
/* a copy of the License at                                                   */
/*                                                                            */
/* http://www.apache.org/licenses/LICENSE-2.0                                 */
/*                                                                            */
/* Unless required by applicable law or agreed to in writing, software        */
/* distributed under the License is distributed on an "AS IS" BASIS,          */
/* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   */
/* See the License for the specific language governing permissions and        */
/* limitations under the License.                                             */
/* -------------------------------------------------------------------------- */

/* ---------------- Log tab plugin ---------------- */

var dataTable_logs;

//setup actions

var log_actions = {
        
    "Log.refresh" : {
        type: "custom",
        call: getLogList,
        error: onError
    },
    "Log.list" : {
        call: getLogList
    }
};

function logElementArray(element){
    parts = element.date_log.split(" ");
    element.date_log = parts[0] + " " + parts[1];
    return [
        element.id,
        element.date_log,
        element.login
    ];
}

function getLogList() {
    var list_array = [];

    $.ajax({
        url: "logs",
        type: "GET",
        dataType: "json",
        success: function (response) {
            $.each(response, function(index, element) {
                if (element != null && element.date_log != null)
                    list_array.push(logElementArray(element));
            });
            updateView(list_array, dataTable_logs);
        },
        error: function (response) {
            console.log("error");
        }
    });
}

var log_buttons = {
    "Log.refresh" : {
        type: "action",
        layout: "refresh",
        alwaysActive: true
    }
};

var logs_tab = {
    title: tr("Logs"),
    resource: 'Log',
    buttons: log_buttons,
    tabClass: "subTab",
    parentTab: "system-tab",
    search_input: '<input id="log_search" type="search" placeholder="'+tr("Search")+'" />',
    list_header: '<i class="fa fa-fw fa-laptop"></i>&emsp;'+tr("Logs"),
    subheader: '<span/> <small></small>&emsp;',
    table: '<table id="datatable_logs" class="datatable twelve">\
        <thead>\
          <tr>\
            <th>' + tr("ID") + '</th>\
            <th>' + tr("DateTimes") + '</th>\
            <th>' + tr("Name") + '</th>\
          </tr>\
        </thead>\
        <tbody id="tbodylogs">\
        </tbody>\
      </table>'
};

Sunstone.addActions(log_actions);
Sunstone.addMainTab('logs-tab',logs_tab);

$(document).ready(function(){
        var tab_name = "logs-tab"
        if (Config.isTabEnabled(tab_name)){
            dataTable_logs = $("#datatable_logs",main_tabs_context).dataTable({
                "bSortClasses": false,
                "bDeferRender": true,
                "aoColumnDefs": [
                    { "bSortable": false, "aTargets": ["check"] },
                    { "sWidth": "35px", "aTargets": [0] },
                    { "bVisible": true, "aTargets": Config.tabTableColumns(tab_name)},
                    { "bVisible": false, "aTargets": ['_all']}
                ]
            });

            $('#log_search').keyup(function(){
                dataTable_logs.fnFilter( $(this).val() );
            })

            getLogList();
            dataTable_logs.fnSort( [ [1,config['user_config']['table_order']] ] );
        }
});
