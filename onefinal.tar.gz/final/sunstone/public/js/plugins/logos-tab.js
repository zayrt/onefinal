var logos_tab_content =
'<form id="create_logo_form" action="">\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="logo">'+tr("Choose your logo")+'</label>\
    <input type="file" name="logo" id="logo" />\
  </div>\
</div>\
</form>';

function buildLogoJSON(name, type, size, content){
    var logo_json = { "logo" :
                      { "name" : name,
                        "type" : type,
                        "size" : size,
                        "content" : content
                      }
                    };
    return logo_json;
};

function setupCreateLogo() {
    $('#logo').change(function(evt){
        var f = evt.target.files[0];

        if (typeof window.FileReader !== 'function') {
            notifyError("The file API isn't supported on this browser yet.");
            return;
        }
        else if (f) {
            var r = new FileReader();
            r.onload = function(e) {
                var contents = e.target.result;
                var logo_json = buildLogoJSON(f.name, f.type, f.size, contents);

                $.ajax({
                    url: "upload_logo",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify(logo_json),
                    contentType: "application/json; charset=utf-8",
                    success: function(response){
                        notifyMessage("The logo has been uploaded");
                    },
                    error: function(response){
                        $.each(response, function(index, element) {
                            if (element.error != undefined){
                                notifyError(element.error.message);
                            }
                        });
                    }
                });
            }
            //r.readAsText(f);
            r.readAsDataURL(f);
        }
        return false;
    });
}

//Setup actions
var logo_actions = {
    "Logo.list": {
        call: function(){}
    }
};

var logos_tab = {
    title: tr("Logos"),
    resource: 'Logo',
    tabClass: "subTab",
    parentTab: "system-tab",
    list_header: '<i class="fa fa-fw fa-camera"></i>&emsp;'+tr("Logos"),
    subheader: '<span/> <small></small>&emsp;',
    content: logos_tab_content
};

Sunstone.addActions(logo_actions);
Sunstone.addMainTab('logos-tab',logos_tab);

//return lists of selected elements in logo list

//This is executed after the sunstone.js ready() is run.
//Here we can basicly init the logo datatable, preload it
//and add specific listeners
$(document).ready(function(){
    var tab_name = "logos-tab"
    if (Config.isTabEnabled(tab_name)){
      //prepare logo datatable
        setupCreateLogo();
    }
});

