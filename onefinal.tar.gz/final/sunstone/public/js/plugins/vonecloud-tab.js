// -------------------------------------------------------------------------- //
// Copyright 2015, OpenNebula Systems SL                                      //
//                                                                            //
// Licensed under the OpenNebula Systems Software License available in a      //
// text file “LICENSE” as part of the distribution                            //
//                                                                            //
// Unless required by applicable law or agreed to in writing, software        //
// distributed under the License is distributed on an "AS IS" BASIS,          //
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   //
// See the License for the specific language governing permissions and        //
// limitations under the License.                                             //
//--------------------------------------------------------------------------- //

var vonecloud_label = '<span style="color:#0098c3"><i class="fa fa-lg fa-fw fa-desktop"></i>&emsp;Control Panel</span>';

var vonecloud_tab = {
  title: vonecloud_label,
  no_content: true
}

OpenNebula["vOneCloud"] = {
    "resource" : 'VONECLOUD',
    "path"     : 'vonecloud/check_version',
    "list" : function(params){
        params.cache_name = "VONECLOUD";
        OpenNebula.Helper.clear_cache(params.cache_name);
        OpenNebula.Action.list(
            params,
            OpenNebula.vOneCloud.resource,
            OpenNebula.vOneCloud.path)
    }
}

var vonecloud_actions = {
    "vOneCloud.list" : {
        type: "list",
        call: OpenNebula.vOneCloud.list,
        callback: function(req, list, res){
            if (res["new_version"]) {
                version_alert = vonecloud_label + '&nbsp;<span style="color:#DC7D24"><i class="fa fa-lg fa-exclamation-circle"></i></span>';

                $("li[id$='vonecloud-tab'] > a > span").html(version_alert);
            }
        }
    }
}

Sunstone.addActions(vonecloud_actions);
Sunstone.addMainTab('vonecloud-tab',vonecloud_tab);

$(document).ready(function(){
    var tab_name = 'vonecloud-tab';

    $("li[id$='vonecloud-tab']").live("click",function(e){
        vonecloud_control_center = document.URL.replace(/(https?:\/\/)([^:\/]+).*$/,"$1$2:8000");
        window.location = vonecloud_control_center;
    });

    Sunstone.runAction('vOneCloud.list');
});
