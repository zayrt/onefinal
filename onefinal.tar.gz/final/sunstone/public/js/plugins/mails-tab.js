var mails_tab_content =
'<form id="create_mail_form" action="">\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="domain_name">'+tr("Domain name")+'</label>\
    <input type="text" name="domain_name" id="domain_name" />\
  </div>\
</div>\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="mail_relay">'+tr("Mail relay")+'</label>\
    <input type="text" name="mail_relay" id="mail_relay" />\
  </div>\
</div>\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="port">'+tr("Port")+'</label>\
    <input type="text" name="port" id="port" />\
  </div>\
</div>\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="username">'+tr("Username")+'</label>\
    <input type="text" name="username" id="username" />\
  </div>\
</div>\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="password">'+tr("Password")+'</label>\
    <input type="text" name="password" id="password" />\
  </div>\
</div>\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="address_cmp">'+tr("Mail CMP")+'</label>\
    <input type="text" name="address_cmp" id="address_cmp" />\
  </div>\
</div>\
<div class="row">\
  <div class="large-6 large-centered columns">\
    <label for="mail_test">'+tr("Mail test")+'</label>\
    <input type="text" name="mail_test" id="mail_test" />\
  </div>\
</div>\
<div class="large-4 large-offset-7 columns">\
        <button class="button radius success" id="create_mail_submit" value="user/create">'+tr("Save and test")+'</button>\
</div>\
</form>';

function buildMailJSON(){
    var domain_name = $('#domain_name').val();
    var mail_relay = $('#mail_relay').val();
    var port = $('#port').val();
    var address_cmp = $('#address_cmp').val();
    var mail_test = $('#mail_test').val();
    var username = $('#username').val();
    var password = $('#password').val();

     var mail_json = { "mail" :
                        { "domain_name" : domain_name,
                          "mail_relay" : mail_relay,
                          "port" : port,
                          "address_cmp" : address_cmp,
                          "mail_test" : mail_test,
                          "username" : username,
                          "password" : password
                        }
                     };
    return mail_json;
};

function getPrevConfig() {
        $.ajax({
            url: "config_mail",
            type: "GET",
            dataType: "json",
            success: function (response) {
                $('#domain_name').val(response.domain_name);
                $('#mail_relay').val(response.mail_relay);
                $('#address_cmp').val(response.address_cmp);
                $('#port').val(response.port);
                $('#username').val(response.username);
                $('#password').val(response.password);
            },
            error: function (response) {
                console.log("error");
            }
       });
}

function setupCreateMail() {
    getPrevConfig();
    $('#create_mail_form').submit(function(){
        var mail_json = buildMailJSON();

        $.ajax({
            url: "config_mail",
            type: "POST",
            dataType: "json",
            data: JSON.stringify(mail_json),
            contentType: "application/json; charset=utf-8",
            success: function(response){
                notifyMessage("The configuration options have been saved");
            },
            error: function(response){
                $.each(response, function(index, element) {
                    if (element.error != undefined){
                        notifyError(element.error.message);
                    }
                });
            }
       });
       return false;
    });
}

var mail_actions = {
    "Mail.list": {
        call: function(){}
    }
};

var mails_tab = {
    title: tr("Mails"),
    resource: 'Mail',
    tabClass: "subTab",
    parentTab: "system-tab",
    list_header: '<i class="fa fa-fw fa-envelope-o"></i>&emsp;'+tr("Mails"),
    subheader: '<span/> <small></small>&emsp;',
    content: mails_tab_content
};

Sunstone.addActions(mail_actions);
Sunstone.addMainTab('mails-tab',mails_tab);

$(document).ready(function(){
    var tab_name = "mails-tab"
    if (Config.isTabEnabled(tab_name)){
      //prepare mail datatable
        setupCreateMail();
    }
});

