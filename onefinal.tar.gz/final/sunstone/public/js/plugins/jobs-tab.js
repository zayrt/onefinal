function setupCreateJobDialog(){
    if ($('#create_job_dialog').length == 0) {
        dialogs_context.append('<div title=\"'+tr("Create job")+'\" id="create_job_dialog"></div>');
    }

    $create_job_dialog = $('#create_job_dialog',dialogs_context);
    var dialog = $create_job_dialog;

    dialog.html(create_job_tmpl);
    dialog.addClass("reveal-modal").attr("data-reveal", "");

    $('#create_job_form',dialog).submit(function(){
        var name=$('#jobname',this).val();
        var job_json = { "job" : { "name" : name}};
        Sunstone.runAction("Job.create",job_json);
        return false;
    });

}

function popUpCreateJobDialog(){
    $create_job_dialog.foundation().foundation('reveal', 'open');
    $("input#name",$create_job_dialog).focus();
    return false;
}

var create_job_tmpl =
'<div class="row">\
  <div class="large-12 columns">\
    <h3 id="create_job_header" class="subheader">'+tr("Create Business")+'</h3>\
  </div>\
</div>\
<form id="create_job_form" action="">\
  <div class="row">\
    <div class="large-12 columns">\
      <label for="jobname">'+tr("Business Name")+':</label>\
      <input type="text" name="jobname" id="jobname" />\
    </div>\
  </div>\
  <div class="form_buttons">\
      <button class="button radius right success" id="create_job_submit" value="job/create">'+tr("Create")+'</button>\
  </div>\
  <a class="close-reveal-modal">&#215;</a>\
</form>';

var dataTable_jobs;
var $create_job_dialog;

var job_actions = {

    "Job.create" : {
        type: "create",
        call: OpenNebula.Job.create,
        callback: function(request, response){
            $create_job_dialog.foundation('reveal', 'close');
            $("form", $create_job_dialog)[0].reset();

            Sunstone.runAction('Job.list');
        },
        error: onError,
        notify: true
    },

    "Job.create_dialog" : {
        type: "custom",
        call: popUpCreateJobDialog
    },

    "Job.list" : {
        type: "list",
        call: OpenNebula.Job.list,
        callback: updateJobsView,
        error: onError
    },

    "Job.show_to_update" : {
        type: "single",
        call: OpenNebula.Job.show,
        error: onError
    },

    "Job.show" : {
        type: "single",
        call: OpenNebula.Job.show,
        callback: function(request, response){
            var tab = dataTable_jobs.parents(".tab");
            if (Sunstone.rightInfoVisible(tab)) {
                // individual view
                updateJobInfo(request, response);
            }
            // datatable row
            updateJobElement(request, response);
        },
        error: onError
    },

    "Job.refresh" : {
        type: "custom",
        call: function(){
          var tab = dataTable_jobs.parents(".tab");
          if (Sunstone.rightInfoVisible(tab)) {
            Sunstone.runAction("Job.show", Sunstone.rightInfoResourceId(tab))
          } else {
            waitingNodes(dataTable_jobs);
            Sunstone.runAction("Job.list", {force: true});
          }
        },
        error: onError
    },

    "Job.delete" : {
        type: "multiple",
        call : OpenNebula.Job.del,
        callback : deleteJobElement,
        elements: jobElements,
        error : onError,
        notify:true
    },

    "Job.rename" : {
        type: "single",
        call: OpenNebula.Job.rename,
        callback: function(request) {
            notifyMessage(tr("Job renamed correctly"));
            Sunstone.runAction('Job.show',request.request.data[0][0]);
        },
        error: onError,
        notify: true
    }
};

var job_buttons = {
    "Job.refresh" : {
        type: "action",
        layout: "refresh",
        alwaysActive: true
    },

    "Job.create_dialog" : {
        type: "create_dialog",
        layout: "create"
    },

    "Job.delete" : {
        type: "confirm",
        layout: "del",
        text: tr("Delete")
    }
};

var jobs_tab = {
    title: tr("Business"),
    resource: 'Job',
    buttons: job_buttons,
    tabClass: "subTab",
    parentTab: "system-tab",
    search_input: '<input id="job_search" type="search" placeholder="'+tr("Search")+'" />',
    list_header: '<i class="fa fa-fw fa-book"></i>&emsp;'+tr("Business"),
    info_header: '<i class="fa fa-fw fa-book"></i>&emsp;'+tr("Business"),
    subheader: '<span/> <small></small>&emsp;',
    table: '<table id="datatable_jobs" class="datatable twelve">\
      <thead>\
        <tr>\
          <th class="check"><input type="checkbox" class="check_all" value=""></input></th>\
          <th>' + tr("ID") + '</th>\
          <th>' + tr("Name") + '</th>\
        </tr>\
      </thead>\
      <tbody id="tbodyjobs">\
      </tbody>\
    </table>'
};

var job_info_panel = {
    "job_info_tab" : {
        title: tr("Job information"),
        content:""
    }
};

Sunstone.addActions(job_actions);
Sunstone.addMainTab('jobs-tab',jobs_tab);
Sunstone.addInfoPanel("job_info_panel",job_info_panel);

function jobElements(){
    return getSelectedNodes(dataTable_jobs);
}

function jobElementArray(element_json){

    var element = element_json;

    return [
        '<input class="check_item" type="checkbox" id="job_'+element.id+'" name="selected_items" value="'+element.id+'"/>',
        element.id,
        element.name,
    ];
}

function updateJobElement(request, element_json){
    var id = element_json.id;
    var element = jobElementArray(element_json);
    updateSingleElement(element,dataTable_jobs,'#job_'+id);
}

//callback for actions deleting a job element
function deleteJobElement(req){
    deleteElement(dataTable_jobs,'#job_'+req.request.data);
    $('div#job_tab_'+req.request.data,main_tabs_context).remove();
}

//call back for actions creating a job element
function addJobElement(request,element_json){
    var id = element_json.id;
    var element = jobElementArray(element_json);
    addElement(element,dataTable_jobs);
}

function updateJobInfo(request,job){
    $(".resource-info-header", $("#jobs-tab")).html(job.name);
    //Information tab
    var info_tab = {
        title : tr("Info"),
        icon: "fa-info-circle",
        content :
        '<div class="row">\
        <div class="large-6 columns">\
        <table id="info_job_table" class="dataTable extended_table">\
            <thead>\
               <tr><th colspan="3">' + tr("Information") +'</th></tr>\
            </thead>\
            <tbody>\
            <tr>\
                <td class="key_td">' + tr("ID") + '</td>\
                <td class="value_td" colspan="2">'+job.id+'</td>\
            </tr>'+
            insert_rename_tr(
                'jobs-tab',
                "Job",
                job.id,
                job.name)+
            '</tbody>\
        </table>\
        </div>\
        <div class="large-6 columns">\
        </div>\
        </div>'
    }
    Sunstone.updateInfoPanelTab("job_info_panel","job_info_tab",info_tab);
    Sunstone.popUpInfoPanel("job_info_panel", "jobs-tab");
}

function updateJobsView (request,list){
    var list_array = [];

    $.ajax({
        url: "job",
        type: "GET",
        dataType: "json",
        success: function (response) {
            $.each(response, function(index, element) {
                list_array.push(jobElementArray(element));
            });
            updateView(list_array, dataTable_jobs);
        },
        error: function (response) {
            console.log("error");
        }
    });
};



$(document).ready(function(){
    var tab_name = "jobs-tab"

    if (Config.isTabEnabled(tab_name)) {
      //prepare job datatable
      dataTable_jobs = $("#datatable_jobs",main_tabs_context).dataTable({
          "bSortClasses": false,
          "bDeferRender": true,
          "aoColumnDefs": [
              { "bSortable": false, "aTargets": ["check"] },
              { "sWidth": "35px", "aTargets": [0] },
              { "bVisible": true, "aTargets": Config.tabTableColumns(tab_name)},
              { "bVisible": false, "aTargets": ['_all']}
          ]
      });

      $('#job_search').keyup(function(){
        dataTable_jobs.fnFilter( $(this).val() );
      })

      dataTable_jobs.on('draw', function(){
        recountCheckboxes(dataTable_jobs);
      })

      Sunstone.runAction("Job.list");
      setupCreateJobDialog();

      dialogs_context.append('<div title=\"'+tr("Create Business")+'\" id="create_job_dialog"></div>');

      initCheckAllBoxes(dataTable_jobs);
      tableCheckboxesListener(dataTable_jobs);
      infoListener(dataTable_jobs, "Job.show");
      dataTable_jobs.fnSort( [ [1,config['user_config']['table_order']] ] );
    }
});
