#!/usr/bin/env ruby
require 'rubygems'
require 'sinatra'
require 'erb'
require 'yaml'
require 'json'
require 'open-uri'
require 'uri'
require 'net/http'
require 'net/https'

class NumergyDriver
    attr_accessor :credentials
    attr_accessor :token
    attr_accessor :version_api
    attr_accessor :uri_api
 
    def initialize(version_api="v3.0", tenantId="8af92dea-7ee5-11e4-b04f-005056992152", accessKey="ARygYfHRXQesxQznTUP0gbjK2wpFMAdBoMWTlaeF", secretKey="zyyqVxvCWJxr4pRxUqPITyc4a6yGYvXUUtVNdD4f")
        @uri_api = "https://api2.numergy.com/"
        @version_api = version_api
        @credentials = {
                            "auth" => {
                                "apiAccessKeyCredentials" => {    
                                    "accessKey" => accessKey,
                                    "secretKey" => secretKey
                                },  
                                "tenantId" => tenantId,
                            } 
                         }
    end

    def createToken
        if !@token.nil? && DateTime.parse(@token["expires"]) > DateTime.now
            return
        end
        uri = URI.parse("#{@uri_api}#{@version_api}/tokens")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json'})         
        req.body = "#{@credentials.to_json}"
        res = https.request(req)
        body = JSON.parse(res.body)
        if !body.nil? && !body["access"].nil?
            token = body["access"]["token"]
        end
        if !token.nil?
            @token= {"id" => token["id"], "expires" => token["expires"]}
        end
        #STDERR.puts "Response #{res.code} #{res.message}: #{res.body}"
    end
    def generate_key(tenant_id)
        createToken
        uri = URI.parse("#{@uri_api}#{@version_api}/#{@credentials["auth"]["tenantId"]}/N-RADM/tenants/#{tenant_id}/keys")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        if @token.nil?
            return
        end
        req = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})
        res = https.request(req)
        STDERR.puts "Response #{res.code} #{res.message}: #{res.body}"
        return [res.code, res.message, res.body]
    end

    def deleteResource(path, id_resource)
        createToken
        uri = URI.parse("#{@uri_api}#{@version_api}/#{@credentials["auth"]["tenantId"]}/#{path}/#{id_resource}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Delete.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})
        res = https.request(req)
        
        STDERR.puts "Response #{res.code} #{res.message}: #{res.body}" 
        return [res.code, res.message, res.body]
    end

    def getListResources(path)
        createToken 
        uri = URI.parse("#{@uri_api}#{@version_api}/#{@credentials["auth"]["tenantId"]}/#{path}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Get.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})         
        res = https.request(req)
        
        puts "Response #{res.code} #{res.message}: #{res.body}"
    end

    def createResource(path, params)
        createToken
        uri = URI.parse("#{@uri_api}#{@version_api}/#{@credentials["auth"]["tenantId"]}/#{path}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})
        req.body = "#{params.to_json}"
        res = https.request(req)

        #STDERR.puts "Response #{res.code} #{res.message}: #{res.body}" 
        return [res.code, res.message, res.body]
    end
end

params_tenant = {"tenant" => {"external_id" => "93390", 
                    "name" => "Démo", 
                    "offer_id" => "4b396b1a-ab16-11e2-b603-005056992152", 
                    "admin_ips" => ["62.23.54.234"], 
                    "customer_id" => "474c0fe6-3785-11e5-bbd3-005056992152", 
                    "customization" => 
                        {"bandwidth" => 20, 
                        "storage_quota" => 10240}, 
                    "metadata" => {"creation_method" => "api"}}}

params_customer = {"customer" => {"external_id" => "93390", "name" => "ForessFoss", "contact" => {"email" => "ilias.zelloufi@neurones.net", "first_name" => "ilyas", "last_name" => "zelloufi", "phone" => "0783052391", "title" => "MR"}}}

n = NumergyDriver.new()
n.generate_key("560e671e-41cf-11e5-bbd3-005056992152")
#n.createResource("N-RADM/tenants", params_tenant)
#n.deleteResource("N-RADM/customers", "beee34b0-39ca-11e5-bbd3-005056992152")
#n.getListResources("flavors")
