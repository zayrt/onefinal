#!/usr/bin/env ruby
require 'rubygems'
require 'sinatra'
require 'erb'
require 'yaml'
require 'json'
require 'open-uri'
require 'uri'
require 'net/http'
require 'net/https'

class NumergyOSDriver
    attr_accessor :credentials
    attr_accessor :token
    attr_accessor :uri_api
 
    def initialize(params)
        @uri_api = "https://cloud.numergy.com/"
        @credentials = {
                            "auth" => {
                                "identity" => {    
                                    "methods" => ["password"],
                                    "password" => {
                                        "user" => {
                                            "domain" => {
                                                "name" => "default"
                                            },
                                            "name" => params["name"],
                                            "password" => params["password"]
                                            
                                        }
                                    }
                                },  
                                "scope" => {
                                    "project" => {
                                        "id" => params["project_id"]
                                    }
                                }                        
                            } 
                         }
    end

    def createToken
        if !@token.nil? && DateTime.parse(@token["expires"]) > DateTime.now
            return
        end
        
        uri = URI.parse("#{@uri_api}identity/v3/auth/tokens")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json'})         
        req.body = "#{@credentials.to_json}"
        res = https.request(req)
        token = JSON.parse(res.body)["token"]
        @token = {"id" => res["X-Subject-Token"], "expires" => token["expires_at"]}
        #STDERR.puts "Response #{res.code} #{res.message}: #{res.body}"
        #STDERR.puts @token.inspect
    end

    def createResource(path, params)
        createToken
        uri = URI.parse("#{@uri_api}#{path}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})
        req.body = "#{params.to_json}"
        res = https.request(req)

        #STDERR.puts "Response #{res.code} #{res.message}: #{res.body}" 
        return [res.code, res.message, res.body]
    end

    def deleteResource(path, id_resource)
        createToken
        uri = URI.parse("#{@uri_api}#{path}/#{id_resource}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Delete.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})
        res = https.request(req)
        
        STDERR.puts "Response #{res.code} #{res.message}: #{res.body}" 
        return [res.code, res.message, res.body]
    end

    

    def getListResources(path)
        createToken 
        uri = URI.parse("#{@uri_api}#{path}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Get.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})         
        res = https.request(req)
        
        puts "Response #{res.code} #{res.message}: #{res.body}"
    end

    def createResource(path, params)
        createToken
        uri = URI.parse("#{@uri_api}#{path}")
        https = Net::HTTP.new(uri.host,uri.port)
        https.use_ssl = true
        req = Net::HTTP::Post.new(uri.path, initheader = {'Content-Type' =>'application/json', 'X-Auth-Token' => @token["id"]})
        req.body = "#{params.to_json}"
        res = https.request(req)

        #STDERR.puts "Response #{res.code} #{res.message}: #{res.body}" 
        return [res.code, res.message, res.body]
    end

    def vm_action(path, params)
        createResource(path, params)
    end

end

params_tos = {
                "partner"=>
                {
                    "id"=> "e4160172-7dc1-09a6-45e7-5485b32ff869"
                },
                "name"=> "tot",
                "tags"=> ["tag1","tag2"],
                "client"=> "client",
                "billingId"=> "bilingid",
                 "description"=> "Description"
             }

a = {
"server"=>
    {
    "name"=>"torin",
    "key_name"=>"mykeypair",
    "imageRef"=>"77f29ff7-dcb1-4293-a96f-e97dbbb2a5f6",
    "flavorRef"=>"100",
    "networks"=>
        [
            {
                "uuid"=>"419e8385-87b0-4be4-96c8-e88d595f9726"
            }
        ]
    }
}

params = {
"name"=>"max.petit@neurones.net",
"password"=>"7C6jV[UY",
"project_id"=>"4791a2b8ef92428cac431c585310d016"
} 

#n = NumergyOSDriver.new(params)
#n.createResource("compute/v2/4791a2b8ef92428cac431c585310d016/servers", a)
#n.vm_action("compute/v2/4791a2b8ef92428cac431c585310d016/servers/e668471b-418b-467d-ad01-e28b46bf99e4/action", {"os-start"=>nil})

#n.createResource("api/projects", params_tos)
#n.createResource("N-RADM/tenants", params_tenant)
#n.deleteResource("N-RADM/customers", "beee34b0-39ca-11e5-bbd3-005056992152")
#n.getListResources("flavors")
