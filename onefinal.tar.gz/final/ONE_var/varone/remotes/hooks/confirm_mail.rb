#!/usr/bin/env ruby

ONE_LOCATION = ENV["ONE_LOCATION"]

if !ONE_LOCATION
    ETC_LOCATION = "/etc/one"
    RUBY_LIB_LOCATION = "/usr/lib/one/ruby"
else
    ETC_LOCATION = ONE_LOCATION + "/etc"
    RUBY_LIB_LOCATION = ONE_LOCATION+"/lib/ruby"
end

DB_CONFIG                 = ETC_LOCATION + "/oned.conf"

require 'digest'
require 'rubygems'
require 'erb'
require 'fileutils'
require 'pony'
require RUBY_LIB_LOCATION + '/onedb/onedb_backend'

id = ARGV[0]
uid = nil
uname = nil
umail = nil
mname = nil
memail = nil
domain = nil
mailrelay = nil
port = nil
username = nil
password = nil

begin
    t = File.read(DB_CONFIG)
    d = t.scan(/(\S+)\s*=\s*"([^"]+)/)
    ops = Hash[d]
    back = BackEndMySQL.new(:server => ops["server"], :port => ops["port"],
        :user => ops["user"], :passwd => ops["passwd"], :db_name => ops["db_name"])
    db = back.connect_db
end

db.fetch("SELECT uid FROM vm_pool WHERE oid='#{id}'") do |row|
    uid = row[:uid]
end

db.fetch("SELECT name FROM user_pool WHERE oid='#{uid}'") do |row|
    uname = row[:name]
end

db.fetch("SELECT * FROM user_annexe WHERE user_id='#{uid}'") do |row|
    umail = row[:email]
    mname = row[:manager_name]
    memail = row[:manager_email]
end

db.fetch("SELECT * FROM config_mail") do |row|
    domain = row[:domain_name]
    mailrelay = row[:mail_relay]
    port = row[:port]
    username = row[:username]
    password = row[:password]
end

db.run("UPDATE vm_annexe SET crypt_id=MD5('#{id}') WHERE vm_id='#{id}'")
crypt_id = Digest::MD5.hexdigest id
active_link = ops["domain_name"] + "/confirmvm/#{crypt_id}"

if username == ""
    username = nil
end
if password == ""
    password = nil
end

Pony.options = {
    :via => :smtp,
    :via_options => {
        :openssl_verify_mode => OpenSSL::SSL::VERIFY_NONE,
        :address              => mailrelay,
        :port                 => port,
        :user_name            => username,
        :password             => password,
        :enable_starttls_auto => true,
        :authentication       => :plain,
        :domain               => domain
    }
}

Pony.mail(:from => "noreply@neurones.net", :to => umail, :subject => "Traitement de votre demande de creation de VM.", :body => "Bonjour #{uname},\n\nNous avons bien pris en compte votre demande pour la mise a disposition de l'environnement suivant.\nUn message a ete envoye au manager afin qu'il valide la creation de cet environnement.\n\nCordialement,\n\nCMP")

Pony.mail(:from => "noreply@neurones.net" ,:to => memail, :subject => "Demande de creation de VM.", :body => "Bonjour #{mname},\n\nL'utilisateur #{uname} a demande la creation d'un environnement. Merci de vous rendre a l'URL suivante si vous validez cette demande:\n#{active_link}\nUne fois valide, l'environnement sera cree et un message sera envoye automatiquement a l'utilisateur. Si nous ne recevons pas de validation de votre part d'ici 24h00, la demande sera detruite.\n\nCordialement,")

db.run("INSERT request_vm (vm_id, date_request) " <<
        "VALUES ("                                <<
        "'#{id}', "                               <<
        "NOW())"
    )

